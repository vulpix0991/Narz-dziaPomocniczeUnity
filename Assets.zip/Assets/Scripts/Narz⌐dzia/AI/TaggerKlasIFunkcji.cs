// Autor: AI (na żądanie Vulpixa)
// Cel: Nadaje tagi klasom i funkcjom na podstawie ich nazwy, zawartości i folderu
// Powiązane: refaktoryzacja, przegląd kodu, analiza architektury

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Narzędzia.Heightmap.AI
{
    public static class TaggerKlasIFunkcji
    {
        private const string outputPath = "Assets/Dokumentacja/tagi_klas_i_funkcji.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Spis klas z tagami")]

    public static void taggerKlasIFunkcji()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new();

            raport.Add("# 🏷 Tagi klas i funkcji\n");
            raport.Add("| Plik | Klasa | Tagi |");
            raport.Add("|------|-------|------|");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileName(plik);
                string sciezka = plik.Replace("Assets/", "").Replace("\\", "/");
                string nazwaKlasy = Path.GetFileNameWithoutExtension(plik);

                List<string> tagi = new();

                // Po nazwie klasy
                if (nazwaKlasy.Contains("Pędzel")) tagi.Add("[Pędzel]");
                if (nazwaKlasy.Contains("GPU")) tagi.Add("[GPU]");
                if (nazwaKlasy.Contains("Test")) tagi.Add("[TEST🗃️]");
                if (nazwaKlasy.Contains("Editor")) tagi.Add("[Editor]");
                if (nazwaKlasy.Contains("System") || nazwaKlasy.Contains("Sterownik")) tagi.Add("[System]");
                if (nazwaKlasy.Contains("Dane") || nazwaKlasy.Contains("Preset")) tagi.Add("[Data]");

                // Po ścieżce
                if (sciezka.Contains("/Pędzle/")) tagi.Add("[Pędzel]");
                if (sciezka.Contains("/GPU/")) tagi.Add("[GPU]");
                if (sciezka.Contains("/Testy/")) tagi.Add("[TEST🗃️]");
                if (sciezka.Contains("/Edytor/")) tagi.Add("[Editor]");
                if (sciezka.Contains("/Dane/")) tagi.Add("[Data]");

                // Po zawartości
                foreach (string linia in linie)
                {
                    if (linia.Contains("Debug.Log")) { tagi.Add("[Debug]"); break; }
                    if (linia.Contains(": ScriptableObject")) { tagi.Add("[Data]"); break; }
                }

                string wynik = tagi.Count > 0 ? string.Join(" ", tagi) : "-";
                raport.Add($"| `{nazwaPliku}` | `{nazwaKlasy}` | {wynik} |");
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);

            Debug.Log($"🏷 Wygenerowano tagi klas i funkcji → {outputPath}");
            AssetDatabase.Refresh();
        }
    }
}
