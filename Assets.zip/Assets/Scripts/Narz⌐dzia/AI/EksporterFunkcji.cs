// Autor: AI (na żądanie Vulpixa)
// Cel: Eksportuje klasy, metody, właściwości i atrybuty ze wszystkich plików .cs do dokumentacji
// Powiązane: analiza kodu, struktura projektu, refaktoryzacja, dokumentacja systemów

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.AI
{
    public static class EksporterFunkcji
    {
        private const string outputMdPath = "Assets/Dokumentacja/funkcje.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Eksporter funkcji i klas")]

    public static void eksporterFunkcji()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new();

            int sumaKlas = 0, sumaMetod = 0, sumaWłaściwości = 0;

            raport.Add("# 📄 Lista klas, metod i właściwości w projekcie\n");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileName(plik);
                int liczbaKlas = 0, liczbaMetod = 0, liczbaProps = 0;

                raport.Add($"## 📄 {nazwaPliku}");

                for (int i = 0; i < linie.Length; i++)
                {
                    string linia = linie[i].Trim();

                    // Atrybuty
                    if (Regex.IsMatch(linia, @"^\[.*\]"))
                    {
                        raport.Add($"🔖 Atrybut: `{linia}`");
                        continue;
                    }

                    // Klasa
                    if (Regex.IsMatch(linia, @"\b(public|internal|private)?\s*(static\s*)?class\s+\w+"))
                    {
                        raport.Add($"🧩 Klasa: `{linia}`");
                        liczbaKlas++;
                        continue;
                    }

                    // Konstruktor
                    if (Regex.IsMatch(linia, @"\b(public|internal|private)?\s+\w+\s*\(.*\)\s*{?") && linia.Contains(nazwaPliku.Replace(".cs", "("))
                        && !linia.Contains("class"))
                    {
                        raport.Add($"🔧 Konstruktor: `{linia}`");
                        liczbaMetod++;
                        continue;
                    }

                    // Metoda
                    if (Regex.IsMatch(linia, @"\b(public|private|protected|internal)\s+(static\s+)?([\w\<\>\[\]]+)\s+\w+\s*\(.*\)\s*{?"))
                    {
                        raport.Add($"🔹 Metoda: `{linia}`");
                        liczbaMetod++;
                        continue;
                    }

                    // Właściwość
                    if (Regex.IsMatch(linia, @"\b(public|private|protected|internal)\s+[\w\<\>\[\]]+\s+\w+\s*\{\s*(get|set)"))
                    {
                        raport.Add($"🔸 Właściwość: `{linia}`");
                        liczbaProps++;
                        continue;
                    }
                }

                sumaKlas += liczbaKlas;
                sumaMetod += liczbaMetod;
                sumaWłaściwości += liczbaProps;

                raport.Add($"📊 W pliku: `{liczbaKlas}` klas, `{liczbaMetod}` metod, `{liczbaProps}` właściwości\n");
            }

            raport.Add("---");
            raport.Add($"### 📦 SUMA");
            raport.Add($"- Klas: `{sumaKlas}`");
            raport.Add($"- Metod: `{sumaMetod}`");
            raport.Add($"- Właściwości: `{sumaWłaściwości}`");
            raport.Add($"- Plików `.cs`: `{pliki.Length}`");

            Directory.CreateDirectory(Path.GetDirectoryName(outputMdPath));
            File.WriteAllLines(outputMdPath, raport);
            AssetDatabase.Refresh();

            Debug.Log($"✅ Eksport funkcji zakończony ({pliki.Length} plików) → {outputMdPath}");
        }
    }
}
