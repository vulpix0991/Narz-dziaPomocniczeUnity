// Autor: AI (na żądanie Vulpixa)
// Cel: Zbiera wszystkie typy danych oznaczone jako [System.Serializable], ScriptableObject, enum, struct
// Powiązane: system danych heightmapy, dokumentacja, analiza kodu

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.AI
{
    public static class SpisTypówDanych
    {
        private const string outputPath = "Assets/Dokumentacja/spis_typów_danych.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/SpisTypówDanych")]

    public static void spisTypówDanych()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new();

            raport.Add("# 📦 Spis typów danych w projekcie\n");
            raport.Add("| Typ | Plik | Pola |");
            raport.Add("|-----|------|------|");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileName(plik);
                string nazwaTypu = "";
                bool isSerializable = false;
                bool isScriptable = false;
                bool isEnum = false;
                bool isStruct = false;
                List<string> pola = new();

                for (int i = 0; i < linie.Length; i++)
                {
                    string linia = linie[i].Trim();

                    if (linia.Contains("[System.Serializable]")) isSerializable = true;
                    if (linia.Contains("class ") && linia.Contains(": ScriptableObject")) isScriptable = true;
                    if (Regex.IsMatch(linia, @"\benum\s+\w+")) isEnum = true;
                    if (Regex.IsMatch(linia, @"\bstruct\s+\w+")) isStruct = true;

                    // Wydobycie nazwy typu
                    if (Regex.IsMatch(linia, @"(class|struct|enum)\s+(\w+)"))
                    {
                        var match = Regex.Match(linia, @"(class|struct|enum)\s+(\w+)");
                        nazwaTypu = match.Groups[2].Value;
                    }

                    // Wydobycie pól
                    if (Regex.IsMatch(linia, @"(public|private|protected)\s+[\w<>\[\]]+\s+\w+;"))
                    {
                        pola.Add(linia.Trim().Replace(";", ""));
                    }
                }

                if ((isSerializable || isScriptable || isEnum || isStruct) && !string.IsNullOrEmpty(nazwaTypu))
                {
                    string polaString = pola.Count > 0 ? string.Join("<br>", pola) : "-";
                    raport.Add($"| `{nazwaTypu}` | `{nazwaPliku}` | {polaString} |");
                }
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);

            Debug.Log($"📦 Wygenerowano spis typów danych → {outputPath}");
            AssetDatabase.Refresh();
        }
    }
}
