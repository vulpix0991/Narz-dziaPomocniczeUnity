// Autor: AI (na żądanie Vulpixa)
// Cel: Śledzi zmiany plików .cs na podstawie SHA1 i tworzy snapshot wersji projektu
// Powiązane: backup, historia zmian, diff

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;

namespace Narzędzia.Heightmap.Backup
{
    public static class VersionTracker
    {
        private const string snapshotPath = "Assets/Dokumentacja/version_snapshot.json";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Backup/VersionTracker")]

    public static void versionTracker()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            Dictionary<string, string> nowySnapshot = new();

            foreach (string plik in pliki)
            {
                if (plik.EndsWith(".meta")) continue;
                string relPath = plik.Replace("\\", "/").Replace("Assets/", "");
                string hash = ObliczSHA1(File.ReadAllText(plik));
                nowySnapshot[relPath] = hash;
            }

            Dictionary<string, string> starySnapshot = new();

            if (File.Exists(snapshotPath))
            {
                string json = File.ReadAllText(snapshotPath);
                starySnapshot = JsonUtility.FromJson<SnapshotContainer>(json).Pliki;
            }

            List<string> raport = new();
            raport.Add("# 🧬 Raport zmian plików .cs\n");

            foreach (var para in nowySnapshot)
            {
                if (!starySnapshot.ContainsKey(para.Key))
                    raport.Add($"🟢 Nowy: `{para.Key}`");
                else if (starySnapshot[para.Key] != para.Value)
                    raport.Add($"🟡 Zmieniony: `{para.Key}`");
                else
                    raport.Add($"✅ Bez zmian: `{para.Key}`");
            }

            foreach (var para in starySnapshot)
            {
                if (!nowySnapshot.ContainsKey(para.Key))
                    raport.Add($"🔴 Usunięty: `{para.Key}`");
            }

            File.WriteAllText(snapshotPath, JsonUtility.ToJson(new SnapshotContainer { Pliki = nowySnapshot }, true));
            File.WriteAllText(snapshotPath.Replace(".json", "_raport.md"), string.Join("\n", raport));

            Debug.Log($"📊 Snapshot zapisany + raport zmian → {snapshotPath}");
            AssetDatabase.Refresh();
        }

        private static string ObliczSHA1(string tekst)
        {
            using var sha1 = SHA1.Create();
            byte[] hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(tekst));
            return System.BitConverter.ToString(hash).Replace("-", "").ToLower();
        }

        [System.Serializable]
        private class SnapshotContainer
        {
            public Dictionary<string, string> Pliki = new();
        }
    }
}
