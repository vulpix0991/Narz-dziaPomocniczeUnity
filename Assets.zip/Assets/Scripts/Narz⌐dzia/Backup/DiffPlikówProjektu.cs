// Autor: AI (na żądanie Vulpixa)
// Cel: Porównuje pliki projektu z kopią zapasową i generuje raport różnic
// Powiązane: backup, rollback, analiza zmian

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Backup
{
    public static class DiffPlikówProjektu
    {
        private const string folderA = "Assets/Scripts";
        private const string folderB = "Kopie/2025-07-10/Scripts";
        private const string outputPath = "Assets/Dokumentacja/różnice_projektu.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Backup/DiffPlikówProjektu")]

    public static void diffPlikówProjektu()
        {
            if (!Directory.Exists(folderB))
            {
                Debug.LogError($"❌ Folder kopii nie istnieje: {folderB}");
                return;
            }

            List<string> raport = new();
            raport.Add("# 🔍 Różnice między projektem a kopią\n");

            Dictionary<string, string> mapaA = PobierzMapę(folderA);
            Dictionary<string, string> mapaB = PobierzMapę(folderB);

            foreach (var plik in mapaA)
            {
                if (!mapaB.ContainsKey(plik.Key))
                {
                    raport.Add($"🔴 Usunięto: `{plik.Key}`");
                }
                else if (plik.Value != mapaB[plik.Key])
                {
                    raport.Add($"🟡 Zmieniono: `{plik.Key}`");
                }
            }

            foreach (var plik in mapaB)
            {
                if (!mapaA.ContainsKey(plik.Key))
                {
                    raport.Add($"🟢 Nowy plik w kopii: `{plik.Key}`");
                }
            }

            if (raport.Count == 1)
                raport.Add("✅ Brak różnic między folderami.");

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);
            AssetDatabase.Refresh();

            Debug.Log($"📄 Diff zakończony. Raport: {outputPath}");
        }

        private static Dictionary<string, string> PobierzMapę(string root)
        {
            var mapa = new Dictionary<string, string>();
            string[] pliki = Directory.GetFiles(root, "*.*", SearchOption.AllDirectories);

            foreach (var plik in pliki)
            {
                if (plik.EndsWith(".meta")) continue;

                string rel = plik.Replace(root, "").TrimStart(Path.DirectorySeparatorChar);
                string hash = ObliczHash(File.ReadAllText(plik));
                mapa[rel] = hash;
            }

            return mapa;
        }

        private static string ObliczHash(string tekst)
        {
            using var sha1 = System.Security.Cryptography.SHA1.Create();
            byte[] hash = sha1.ComputeHash(System.Text.Encoding.UTF8.GetBytes(tekst));
            return System.BitConverter.ToString(hash).Replace("-", "").ToLower();
        }
    }
}
