// Autor: AI (na żądanie Vulpixa)
// Cel: SZABLON – BrushTransform
// Powiązane: brak

using UnityEngine;

namespace Heightmap.BrushTools
{
    public class BrushTransform : MonoBehaviour
    {
        // TODO: Implementacja
    }
}