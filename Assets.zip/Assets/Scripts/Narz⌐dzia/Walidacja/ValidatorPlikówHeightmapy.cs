// Autor: AI (na żądanie Vulpixa)
// Cel: Sprawdza zgodność kodu projektu z ZASADY_AI.md i generuje raport błędów
// Powiązane: walidacja projektu, checklisty błędów, automatyczne audyty

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Narzędzia.Heightmap.Walidacja
{
    public static class ValidatorPlikówHeightmapy
    {
        private const string outputPath = "Assets/Dokumentacja/CHECKLISTY_BŁĘDÓW.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Validator projektu")]

    public static void validatorPlikówHeightmapy()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);

            List<string> błędy = new();
            błędy.Add("# ❗ Lista błędów i ostrzeżeń w kodzie\n");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwa = Path.GetFileName(plik);

                int klasy = 0;
                bool maNamespace = false;
                bool maNagłówek = false;
                bool maSerializable = false;
                bool zawieraUpdate = false;
                bool updateZLogiką = false;

                for (int i = 0; i < linie.Length; i++)
                {
                    string l = linie[i].Trim();

                    if (l.StartsWith("namespace ")) maNamespace = true;
                    if (l.Contains("class ")) klasy++;
                    if (l.Contains("[System.Serializable]")) maSerializable = true;
                    if (l.StartsWith("// Autor:")) maNagłówek = true;
                    if (l.Contains("GameObject.Find(")) błędy.Add($"🔴 `{nazwa}` → użycie GameObject.Find() w linii {i + 1}");
                    if (l.Contains("void Update(")) zawieraUpdate = true;

                    if (zawieraUpdate && (l.Contains("Input.") || l.Contains("GetKey") || l.Contains("if(")))
                        updateZLogiką = true;
                }

                if (!maNamespace)
                    błędy.Add($"❌ `{nazwa}` → brak namespace");

                if (!maNagłówek)
                    błędy.Add($"❌ `{nazwa}` → brak nagłówka AI");

                if (!maSerializable && nazwa.StartsWith("Dane"))
                    błędy.Add($"❌ `{nazwa}` → brak [System.Serializable]");

                if (klasy > 1)
                    błędy.Add($"⚠️ `{nazwa}` → więcej niż jedna klasa w pliku");

                if (updateZLogiką)
                    błędy.Add($"🔶 `{nazwa}` → logika w Update()");
            }

            if (błędy.Count == 1)
                błędy.Add("✅ Brak błędów zgodności z ZASADY_AI.md");

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, błędy);
            AssetDatabase.Refresh();

            Debug.Log($"🛡 Walidacja zakończona → {outputPath}");
        }
    }
}
  