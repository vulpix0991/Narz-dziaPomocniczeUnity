// Autor: AI (na żądanie Vulpixa)
// Cel: Zlicza tagi typu DEBUG, TODO, HACK, FIXME w całym kodzie
// Powiązane: debugowanie, refaktoryzacja, kontrola jakości kodu

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Walidacja
{
    public static class LicznikTagówDebug
    {
        private const string outputPath = "Assets/Dokumentacja/tagi_debug.md";

        private static readonly string[] tagi =
        {
            "// DEBUG", "// TODO", "// HACK", "// FIXME", "#if UNITY_EDITOR", "#region", "#pragma warning"
        };

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Zlicz tagi TODO / DEBUG")]

    public static void licznikTagówDebug()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            Dictionary<string, Dictionary<string, int>> raport = new();

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwa = Path.GetFileName(plik);

                foreach (string tag in tagi)
                {
                    foreach (string linia in linie)
                    {
                        if (linia.Contains(tag))
                        {
                            if (!raport.ContainsKey(nazwa))
                                raport[nazwa] = new Dictionary<string, int>();

                            if (!raport[nazwa].ContainsKey(tag))
                                raport[nazwa][tag] = 0;

                            raport[nazwa][tag]++;
                        }
                    }
                }
            }

            List<string> wynik = new();
            wynik.Add("# 🧮 Liczba tagów TODO / DEBUG / HACK w projekcie\n");

            foreach (var plik in raport)
            {
                wynik.Add($"## {plik.Key}");
                foreach (var tag in plik.Value)
                {
                    wynik.Add($"- {tag.Key}: **{tag.Value}**");
                }
                wynik.Add("");
            }

            if (raport.Count == 0)
                wynik.Add("✅ Nie znaleziono tagów tymczasowych.");

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, wynik);
            AssetDatabase.Refresh();

            Debug.Log($"🧮 Wygenerowano licznik tagów debug → {outputPath}");
        }
    }
}
