﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Uruchamia debug sceny – eksport i odpala czekacza na plik
// Powiązane: PlikEksportuHelper.cs, CzekaczNaPlik.cs

using UnityEngine;
using UnityEditor;
using UnityEngine.SceneManagement;

namespace Heightmap.Narzędzia.Automatyzacja
{
    public static class DebugerSceny
    {
        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Debug/🧠 Debuguj aktywną scenę (eksport + analiza)")]
        public static void DebugujScene()
        {
            var scena = SceneManager.GetActiveScene();

            if (!scena.IsValid())
            {
                Debug.LogError("❌ Nie można uzyskać aktywnej sceny."); // DEBUG
                return;
            }

            string nazwaSceny = scena.name;
            string sciezka = PlikEksportuHelper.PrzygotujPlikEksportu(nazwaSceny);

            if (string.IsNullOrEmpty(sciezka))
            {
                Debug.LogError("❌ Nie można kontynuować – brak ścieżki eksportu."); // DEBUG
                return;
            }

            Debug.Log($"📤 Rozpoczynam eksport hierarchii sceny `{nazwaSceny}`...");

            try
            {
                Eksport.EksportSceny.EksportujHierarchie();
            }
            catch (System.Exception ex)
            {
                Debug.LogError("❌ Błąd eksportu: " + ex.Message);
                return;
            }

            Debug.Log("⏳ Czekam na pojawienie się pliku, aby uruchomić analizę..."); // DEBUG
            CzekaczNaPlik.Czekaj(sciezka);
        }
    }
}
