﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Czeka aż pojawi się plik .txt i uruchamia analizę
// Powiązane: DebugerSceny.cs

using UnityEngine;
using UnityEditor;
using System;
using System.IO;

namespace Heightmap.Narzędzia.Automatyzacja
{
    public static class CzekaczNaPlik
    {
        private static string _plik;
        private static DateTime _start;
        private static EditorApplication.CallbackFunction _callback;

        public static void Czekaj(string sciezkaPliku)
        {
            if (string.IsNullOrEmpty(sciezkaPliku))
            {
                Debug.LogError("❌ Ścieżka do pliku eksportu jest pusta – przerwano oczekiwanie."); // DEBUG
                return;
            }

            _plik = sciezkaPliku;
            _start = DateTime.Now;
            _callback = Sprawdz;

            Debug.Log("👀 Nasłuchiwanie pliku: " + _plik); // DEBUG
            EditorApplication.update += _callback;
        }

        private static void Sprawdz()
        {
            try
            {
                if ((DateTime.Now - _start).TotalSeconds > 10)
                {
                    Debug.LogError("⏱ Timeout: plik eksportu nie pojawił się w 10 sekund."); // DEBUG
                    return;
                }

                if (File.Exists(_plik))
                {
                    Debug.Log("📄 Plik gotowy – rozpoczynam analizę: " + _plik); // DEBUG
                    try
                    {
                        Analiza.AnalizaStatystyk.Analizuj();
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError("❌ Błąd analizy: " + ex.Message);
                    }
                    finally
                    {
                        EditorApplication.update -= _callback;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("❌ Błąd nasłuchiwania pliku: " + ex.Message); // DEBUG
                EditorApplication.update -= _callback;
            }
        }
    }
}
