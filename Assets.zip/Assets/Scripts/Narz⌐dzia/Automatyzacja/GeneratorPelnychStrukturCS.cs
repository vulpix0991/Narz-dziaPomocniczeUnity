﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Zbiera wszystkie pliki tekstowe (.cs, .shader, .json, .md...) do jednego .txt
// Powiązane: analiza projektu, backup, snapshot, inspekcja AI

using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;

namespace Heightmap.Narzędzia.Automatyzacja
{
    public static class GeneratorPelnychStrukturCS
    {
        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/📦 Zbierz wszystkie pliki tekstowe do .txt")]
        public static void ZbierzWszystkieTekstowe()
        {
            string katalogStart = Application.dataPath; // czyli /Assets
            string[] rozszerzenia = { ".cs", ".shader", ".cginc", ".compute", ".json", ".md", ".txt", ".uss", ".asmdef" };
            string[] wszystkiePliki = Directory.GetFiles(katalogStart, "*.*", SearchOption.AllDirectories)
                .Where(f => rozszerzenia.Any(ext => f.EndsWith(ext)))
                .ToArray();

            string sciezkaWyniku = Path.Combine(Application.dataPath, "../WszystkiePlikiTekstowe.txt");

            using (StreamWriter writer = new StreamWriter(sciezkaWyniku, false))
            {
                writer.WriteLine("// 📦 Wygenerowano przez GeneratorPelnychStrukturCS");
                writer.WriteLine("// Zawartość wszystkich plików tekstowych projektu\n");

                foreach (string pelnaSciezka in wszystkiePliki)
                {
                    string lokalnaSciezka = pelnaSciezka.Replace("\\", "/").Replace(Application.dataPath, "Assets");
                    writer.WriteLine("////////////////////////////////////////////////////////////////////////");
                    writer.WriteLine("// Plik: " + lokalnaSciezka);
                    writer.WriteLine("////////////////////////////////////////////////////////////////////////\n");

                    try
                    {
                        string[] linie = File.ReadAllLines(pelnaSciezka);
                        foreach (string linia in linie)
                        {
                            writer.WriteLine(linia);
                        }
                        writer.WriteLine("\n\n");
                        Debug.Log("✅ Dodano: " + lokalnaSciezka);
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError("❌ Błąd odczytu pliku: " + lokalnaSciezka + "\n" + ex.Message);
                    }
                }

                Debug.Log("📦 Gotowe! Plik zbiorczy: " + sciezkaWyniku);
            }

            AssetDatabase.Refresh();
        }
    }
}
