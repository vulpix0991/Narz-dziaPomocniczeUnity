﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Generuje raport .md na podstawie danych z ParserHierarchii
// Powiązane: DaneStatystyk, AnalizaStatystyk.cs

using System;
using System.IO;
using System.Linq;
using System.Text;

namespace Heightmap.Narzędzia.Automatyzacja.Analiza
{
    public static class RaportMarkdown
    {
        public static void Generuj(DaneStatystyk d, string scena, string sciezka)
        {
            try
            {
                using StreamWriter sw = new StreamWriter(sciezka, false, Encoding.UTF8);

                sw.WriteLine($"# 🧪 Raport: HierarchiaDebug – scena: `{scena}`");
                sw.WriteLine($"Data: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n");

                sw.WriteLine($"## 📊 Statystyki ogólne");
                sw.WriteLine($"- 🎮 Liczba GameObjectów: **{d.obiekty}**");
                sw.WriteLine($"- 🧩 Liczba komponentów: **{d.komponenty}**");
                sw.WriteLine($"- ⚠️ Null komponentów: **{d.nullKomponenty}**");
                sw.WriteLine($"- ⛔ Obiekty bez komponentów: **{d.bezKomponentów}**\n");

                sw.WriteLine($"## 🚨 Problemy potencjalne:");
                sw.WriteLine($"- 🔇 AudioSource bez clip: **{d.audioBezClip}**");
                sw.WriteLine($"- 🎭 Animator bez kontrolera: **{d.animatorBezKontrolera}**");
                sw.WriteLine($"- 🏷️ Untagged: **{d.untagged}**");
                sw.WriteLine($"- 🧱 Warstwa Default: **{d.defaultLayer}**\n");

                sw.WriteLine($"## ⚙️ Diagnostyka systemowa:");
                sw.WriteLine($"- 🎧 AudioListener: **{d.audioListenerCount}**");
                if (d.audioListenerCount > 1)
                    sw.WriteLine("  ⚠️ Więcej niż 1 AudioListener – może powodować problemy");
                sw.WriteLine($"- 🧭 EventSystem: **{d.eventSystemCount}**");
                if (d.eventSystemCount == 0)
                    sw.WriteLine("  ⚠️ Brak EventSystem – UI może nie działać\n");

                sw.WriteLine("## 🔍 Przykładowe obiekty z problemami:");
                if (d.ostatnieBledy.Count == 0)
                {
                    sw.WriteLine("- ✅ Brak wykrytych błędów w obiektach!");
                }
                else
                {
                    foreach (var para in d.ostatnieBledy.Reverse().Take(3))
                        sw.WriteLine($"- `{para.Key}` → {para.Value}");
                }

                sw.WriteLine($"\n## 📌 Podsumowanie błędów:");
                int suma = d.nullKomponenty + d.bezKomponentów + d.audioBezClip + d.animatorBezKontrolera + d.untagged + d.defaultLayer;
                if (suma == 0)
                    sw.WriteLine("- ✅ Nie wykryto błędów ani ostrzeżeń.");
                else
                    sw.WriteLine($"- ⚠️ Łącznie potencjalnych problemów: **{suma}**");

                sw.WriteLine("\n✅ Analiza zakończona.");
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"❌ Błąd podczas generowania raportu Markdown: {ex.Message}"); // DEBUG
            }
        }
    }
}
