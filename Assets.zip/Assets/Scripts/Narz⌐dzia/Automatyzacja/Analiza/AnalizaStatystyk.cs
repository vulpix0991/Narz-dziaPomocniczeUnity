﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Punkt startowy analizy pliku hierarchii sceny
// Powiązane: ParserHierarchii.cs, RaportMarkdown.cs

using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System;

namespace Heightmap.Narzędzia.Automatyzacja.Analiza
{
    public static class AnalizaStatystyk
    {
        public static void Analizuj()
        {
            try
            {
                string folder = Path.Combine(Application.dataPath, "../Eksport");

                if (!Directory.Exists(folder))
                {
                    Debug.LogWarning("⚠️ Folder Eksport/ nie istnieje."); // DEBUG
                    return;
                }

                string[] pliki = Directory.GetFiles(folder, "HierarchiaDebug_*.txt");
                if (pliki.Length == 0)
                {
                    Debug.LogWarning("⚠️ Brak plików do analizy."); // DEBUG
                    return;
                }

                string ostatni = pliki.OrderByDescending(File.GetLastWriteTime).First();
                string scena = Path.GetFileNameWithoutExtension(ostatni).Replace("HierarchiaDebug_", "");
                string wynik = Path.Combine(folder, $"HierarchiaDebug_{scena}_Statystyki.md");

                Debug.Log($"📥 Wczytywanie pliku: {ostatni}"); // DEBUG

                string[] linie = File.ReadAllLines(ostatni);
                if (linie == null || linie.Length == 0)
                {
                    Debug.LogError("❌ Plik eksportu jest pusty lub nieczytelny."); // DEBUG
                    return;
                }

                var dane = ParserHierarchii.Przetworz(linie);
                RaportMarkdown.Generuj(dane, scena, wynik);

                Debug.Log($"✅ Raport .md wygenerowany: {wynik}"); // DEBUG
                AssetDatabase.Refresh();
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas analizy pliku hierarchii: {ex.Message}"); // DEBUG
            }
        }
    }
}
