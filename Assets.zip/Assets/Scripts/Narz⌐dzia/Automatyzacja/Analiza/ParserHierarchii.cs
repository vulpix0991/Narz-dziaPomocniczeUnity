﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Parsuje linie pliku .txt na dane statystyczne do raportu
// Powiązane: RaportMarkdown.cs

using System.Collections.Generic;
using System;

namespace Heightmap.Narzędzia.Automatyzacja.Analiza
{
    public class DaneStatystyk
    {
        public int obiekty, komponenty, nullKomponenty, audioBezClip,
                   animatorBezKontrolera, untagged, defaultLayer,
                   audioListenerCount, eventSystemCount, bezKomponentów;

        public int nieaktywneObiekty, duplikatyNazw;

        public Dictionary<string, string> ostatnieBledy = new();

        internal HashSet<string> widzianeNazwy = new(); // UDOSTĘPNIONE parserowi
    }

    public static class ParserHierarchii
    {
        public static DaneStatystyk Przetworz(string[] linie)
        {
            var dane = new DaneStatystyk();
            string aktualny = "";

            for (int i = 0; i < linie.Length; i++)
            {
                string linia = linie[i];
                string trimmed = linia.Trim();

                try
                {
                    if (string.IsNullOrWhiteSpace(trimmed))
                    {
                        aktualny = "";
                        continue;
                    }

                    if (trimmed.StartsWith("- GameObject:"))
                    {
                        dane.obiekty++;
                        aktualny = trimmed.Substring(13).Trim();

                        // Duplikaty nazw
                        if (dane.widzianeNazwy.Contains(aktualny))
                            dane.duplikatyNazw++;
                        else
                            dane.widzianeNazwy.Add(aktualny);
                    }
                    else if (trimmed.Contains("⚠️ Brakujący komponent"))
                    {
                        dane.nullKomponenty++;
                        if (aktualny != "")
                            dane.ostatnieBledy[aktualny] = "⚠️ Brakujący komponent";
                    }
                    else if (trimmed.StartsWith("▸"))
                    {
                        dane.komponenty++;
                        string typ = trimmed.Substring(1).Trim();
                        if (typ == "AudioSource") dane.audioBezClip++;
                        if (typ == "Animator") dane.animatorBezKontrolera++;
                        if (typ == "AudioListener") dane.audioListenerCount++;
                        if (typ == "EventSystem") dane.eventSystemCount++;
                    }
                    else if (trimmed.StartsWith("Tag: Untagged"))
                    {
                        dane.untagged++;
                        if (aktualny != "")
                            dane.ostatnieBledy[aktualny] = "Tag = Untagged";
                    }
                    else if (trimmed.StartsWith("Layer: Default"))
                    {
                        dane.defaultLayer++;
                        if (aktualny != "")
                            dane.ostatnieBledy[aktualny] = "Layer = Default";
                    }
                    else if (trimmed.Contains("Komponenty:") && trimmed.EndsWith("0"))
                    {
                        dane.bezKomponentów++;
                    }
                    else if (trimmed.StartsWith("ActiveSelf: False"))
                    {
                        dane.nieaktywneObiekty++;
                        if (aktualny != "")
                            dane.ostatnieBledy[aktualny] = "Obiekt nieaktywny";
                    }
                }
                catch (Exception ex)
                {
                    UnityEngine.Debug.LogError($"❌ Błąd parsera w linii {i}: \"{trimmed}\" – {ex.Message}"); // DEBUG
                }
            }

            return dane;
        }
    }
}
