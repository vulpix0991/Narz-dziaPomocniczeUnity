﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Zbiera dane z GameObjectów i ich komponentów w hierarchii
// Powiązane: FormatterHierarchii.cs

using UnityEngine;
using UnityEditor;
using System.Text;
using System;

namespace Heightmap.Narzędzia.Automatyzacja.Eksport
{
    public static class ZbieraczHierarchii
    {
        public static void Zbierz(GameObject obiekt, int poziom, StringBuilder sb)
        {
            if (obiekt == null)
            {
                Debug.LogError("❌ Obiekt przekazany do ZbieraczHierarchii.Zbierz() jest null!"); // DEBUG
                return;
            }

            string indent = new string(' ', poziom * 2);
            sb.AppendLine($"{indent}- GameObject: {obiekt.name}");

            try
            {
                sb.AppendLine($"{indent}  ActiveSelf: {obiekt.activeSelf}");
                sb.AppendLine($"{indent}  Tag: {obiekt.tag}");
                sb.AppendLine($"{indent}  Layer: {LayerMask.LayerToName(obiekt.layer)}");
                sb.AppendLine($"{indent}  Static: {GameObjectUtility.AreStaticEditorFlagsSet(obiekt, StaticEditorFlags.BatchingStatic)}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas odczytu danych ogólnych obiektu {obiekt.name}: {ex.Message}"); // DEBUG
            }

            try
            {
                var t = obiekt.transform;
                sb.AppendLine($"{indent}  Transform:");
                sb.AppendLine($"{indent}    Position: {t.localPosition}");
                sb.AppendLine($"{indent}    Rotation: {t.localEulerAngles}");
                sb.AppendLine($"{indent}    Scale:    {t.localScale}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas odczytu Transform obiektu {obiekt.name}: {ex.Message}"); // DEBUG
            }

            try
            {
                var komponenty = obiekt.GetComponents<Component>();
                if (komponenty.Length > 0)
                {
                    sb.AppendLine($"{indent}  Komponenty:");
                    foreach (var c in komponenty)
                    {
                        if (c == null)
                        {
                            sb.AppendLine($"{indent}    ⚠️ Brakujący komponent (null)");
                        }
                        else
                        {
                            sb.AppendLine($"{indent}    ▸ {c.GetType().Name}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas odczytu komponentów obiektu {obiekt.name}: {ex.Message}"); // DEBUG
            }

            sb.AppendLine();

            try
            {
                for (int i = 0; i < obiekt.transform.childCount; i++)
                {
                    var dziecko = obiekt.transform.GetChild(i)?.gameObject;
                    Zbierz(dziecko, poziom + 1, sb);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas przetwarzania dzieci obiektu {obiekt.name}: {ex.Message}"); // DEBUG
            }
        }
    }
}
