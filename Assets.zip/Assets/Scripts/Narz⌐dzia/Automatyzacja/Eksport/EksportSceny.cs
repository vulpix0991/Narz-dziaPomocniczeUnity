﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Punkt startowy eksportu hierarchii aktywnej sceny
// Powiązane: ZbieraczHierarchii.cs, FormatterHierarchii.cs

using UnityEngine;
using UnityEditor;
using UnityEngine.SceneManagement;
using System.IO;
using System;

namespace Heightmap.Narzędzia.Automatyzacja.Eksport
{
    public static class EksportSceny
    {
        public static void EksportujHierarchie()
        {
            try
            {
                var scena = SceneManager.GetActiveScene();
                if (!scena.IsValid())
                {
                    Debug.LogError("❌ Nie można uzyskać aktywnej sceny – eksport przerwany."); // DEBUG
                    return;
                }

                var obiektyRoot = scena.GetRootGameObjects();
                var folder = Path.Combine(Application.dataPath, "../Eksport");

                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                    Debug.Log("📁 Utworzono folder eksportu: " + folder); // DEBUG
                }

                var sciezka = Path.Combine(folder, $"HierarchiaDebug_{scena.name}.txt");
                var tekst = FormatterHierarchii.Formatuj(scena.name, obiektyRoot);

                File.WriteAllText(sciezka, tekst);
                Debug.Log("✅ Eksport zakończony: " + sciezka);
                AssetDatabase.Refresh();
            }
            catch (Exception ex)
            {
                Debug.LogError("❌ Błąd podczas eksportu hierarchii sceny: " + ex.Message); // DEBUG
            }
        }
    }
}
