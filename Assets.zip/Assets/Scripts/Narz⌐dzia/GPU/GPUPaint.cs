// Autor: AI (na żądanie Vulpixa)
// Cel: SZABLON – GPUPaint
// Powiązane: brak

using UnityEngine;

namespace Heightmap.GPU
{
    public class GPUPaint : MonoBehaviour
    {
        // TODO: Implementacja
    }
}