// Autor: AI (na żądanie Vulpixa)
// Cel: Uruchamia testy jednostkowe z klas Test*.cs bez Unity TestRunnera
// Powiązane: testy pędzli, blur, stitching, heightmapa

using UnityEditor;
using UnityEngine;
using System;
using System.Reflection;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Testy
{
    public static class UruchomTestyOffline
    {
        private const string folderTestów = "Assets/Scripts/Narzędzia/Testy";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Testy/Uruchom testy offline")]
        public static void uruchomTestyOffline()
        {
            if (!Directory.Exists(folderTestów))
            {
                Debug.LogWarning($"⚠️ Brak folderu: {folderTestów} – nie znaleziono testów.");
                return;
            }

            Debug.Log("🧪 ======================================");
            Debug.Log("🧪 ROZPOCZYNAM TESTY OFFLINE...");
            Debug.Log("🧪 ======================================");

            string[] pliki = Directory.GetFiles(folderTestów, "Test*.cs", SearchOption.AllDirectories);
            int udane = 0;
            int błędy = 0;
            List<string> listaBłędów = new();

            foreach (string plik in pliki)
            {
                string klasa = Path.GetFileNameWithoutExtension(plik);
                string pełnaNazwa = $"Narzędzia.Heightmap.Testy.{klasa}";

                Type typ = Type.GetType(pełnaNazwa);
                if (typ == null)
                {
                    Debug.LogWarning($"⚠️ Nie znaleziono klasy testowej: {pełnaNazwa}");
                    continue;
                }

                MethodInfo metoda = typ.GetMethod("RunTest", BindingFlags.Public | BindingFlags.Static);
                if (metoda == null)
                {
                    Debug.LogWarning($"⚠️ Brak metody RunTest() w klasie {klasa}");
                    continue;
                }

                try
                {
                    Debug.Log($"▶️ Uruchamiam: {klasa}.RunTest()");
                    metoda.Invoke(null, null);
                    Debug.Log($"✅ OK: {klasa}");
                    udane++;
                }
                catch (TargetInvocationException ex)
                {
                    string msg = ex.InnerException?.Message ?? ex.Message;
                    Debug.LogError($"❌ Błąd w {klasa}.RunTest(): {msg}");
                    listaBłędów.Add($"{klasa} – {msg}");
                    błędy++;
                }
                catch (Exception ex)
                {
                    Debug.LogError($"❌ Wyjątek krytyczny w {klasa}: {ex.Message}");
                    listaBłędów.Add($"{klasa} – {ex.Message}");
                    błędy++;
                }
            }

            Debug.Log("🧪 ======================================");
            Debug.Log($"🧪 TESTY ZAKOŃCZONE: ✅ Udane = {udane}, ❌ Błędy = {błędy}");
            if (listaBłędów.Count > 0)
            {
                Debug.Log("🧪 🧨 Lista błędów:");
                foreach (var błąd in listaBłędów)
                    Debug.Log($"   • {błąd}");
            }
            Debug.Log("🧪 ======================================");
        }
    }
}
