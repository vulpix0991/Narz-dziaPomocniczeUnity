// Autor: AI (na żądanie Vulpixa)
// Cel: Eksportuje relacje prefabów i ich przypiętych komponentów MonoBehaviour
// Powiązane: dokumentacja, prefab → kod, debug

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Edytor
{
    public static class EksporterRelacjiPrefab
    {
        private const string katalogPrefabow = "Assets/Prefaby";
        private const string outputPath = "Assets/Dokumentacja/relacje_prefab_skrzpty.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/EksporterRelacjiPrefab")]

    public static void eksporterRelacjiPrefab()
        {
            if (!Directory.Exists(katalogPrefabow))
            {
                Debug.LogWarning($"⚠ EksporterRelacjiPrefab: Folder '{katalogPrefabow}' nie istnieje – pomijam generowanie.");
                return;
            }

            string[] prefabPaths = Directory.GetFiles(katalogPrefabow, "*.prefab", SearchOption.AllDirectories);
            if (prefabPaths.Length == 0)
            {
                Debug.LogWarning("⚠ EksporterRelacjiPrefab: Nie znaleziono żadnych prefabów w katalogu.");
                return;
            }

            List<string> raport = new() { "# 🕸 Relacje prefabów ↔ komponenty\n" };

            foreach (string path in prefabPaths)
            {
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null)
                {
                    Debug.LogWarning($"⚠ Nie udało się załadować prefabu: {path}");
                    continue;
                }

                HashSet<string> komponenty = new(); // unikalne typy
                foreach (var s in prefab.GetComponentsInChildren<MonoBehaviour>(true))
                {
                    if (s != null)
                        komponenty.Add(s.GetType().Name);
                }

                foreach (var c in prefab.GetComponentsInChildren<Component>(true))
                {
                    if (c == null) continue;
                    string typ = c.GetType().Name;
                    switch (typ)
                    {
                        case "Terrain":
                        case "Canvas":
                        case "Collider":
                        case "Animator":
                        case "Slider":
                        case "Rigidbody":
                        case "Text":
                        case "Image":
                            komponenty.Add(typ);
                            break;
                    }
                }

                string relacja = komponenty.Count > 0 ? string.Join(", ", new List<string>(komponenty).ToArray()) : "-";
                string relPrefab = path.Replace("Assets/", "");
                raport.Add($"- **{relPrefab}** → `{relacja}`");
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);
            AssetDatabase.Refresh();
            Debug.Log($"✅ EksporterRelacjiPrefab: wygenerowano do → {outputPath}");
        }
    }
}
