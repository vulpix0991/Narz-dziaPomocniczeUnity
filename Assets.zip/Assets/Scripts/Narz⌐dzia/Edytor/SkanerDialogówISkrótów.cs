// Autor: AI (na żądanie Vulpixa)
// Cel: Wyszukuje skróty klawiszowe oraz użycie okien dialogowych i UI edytora
// Powiązane: debugowanie UI edytora, konflikty skrótów, refaktoryzacja edytora

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Edytor
{
    public static class SkanerDialogówISkrótów
    {
        private const string outputPath = "Assets/Dokumentacja/skróty_i_dialogi.md";

        private static readonly string[] frazySkrótów =
        {
            "Input.GetKey", "Input.GetKeyDown", "KeyCode.",
            "Event.current", "control", "shift", "alt",
            "ShortcutManager.RegisterShortcut"
        };

        private static readonly string[] frazyDialogów =
        {
            "EditorUtility.DisplayDialog",
            "EditorUtility.OpenFilePanel",
            "EditorGUI.Popup",
            "GUILayout.Button",
            "EditorGUILayout.Toggle",
            "EditorGUILayout.Slider"
        };

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/SkanerDialogówISkrótów")]

    public static void skanerDialogówISkrótów()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new();

            raport.Add("# ⌨️ Skróty klawiaturowe i wywołania UI w kodzie\n");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                List<string> trafienia = new();
                string nazwaPliku = plik.Replace("Assets/", "");

                for (int i = 0; i < linie.Length; i++)
                {
                    string linia = linie[i].Trim();
                    foreach (var fraza in frazySkrótów)
                    {
                        if (linia.Contains(fraza))
                            trafienia.Add($"🔑 [{i + 1}] {fraza} → `{linia}`");
                    }

                    foreach (var fraza in frazyDialogów)
                    {
                        if (linia.Contains(fraza))
                            trafienia.Add($"💬 [{i + 1}] {fraza} → `{linia}`");
                    }
                }

                if (trafienia.Count > 0)
                {
                    raport.Add($"## 📄 {nazwaPliku}");
                    raport.AddRange(trafienia);
                    raport.Add("");
                }
            }

            if (raport.Count == 1)
                raport.Add("✅ Nie znaleziono żadnych skrótów ani dialogów.");

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);
            AssetDatabase.Refresh();

            Debug.Log($"⌨️ Wygenerowano raport skrótów i dialogów → {outputPath}");
        }
    }
}
