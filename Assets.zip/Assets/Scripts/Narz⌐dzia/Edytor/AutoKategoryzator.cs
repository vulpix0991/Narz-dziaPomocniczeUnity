// Autor: AI (na żądanie Vulpixa)
// Cel: Wyszukuje pliki niezgodne ze strukturą folderów i proponuje ich relokację
// Powiązane: struktura projektu, porządek, ZASADY_AI.md

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Narzędzia.Heightmap.Edytor
{
    public static class AutoKategoryzator
    {
        private const string outputPath = "Assets/Dokumentacja/proponowane_przeniesienia.md";

        private static readonly Dictionary<string, string> regułyFolderów = new()
        {
            { "Test",      "Testy" },
            { "Pędzel",    "Narzędzia/Pędzle" },
            { "GPU",       "GPU" },
            { "Edytor",    "Edytor" },
            { "System",    "Systemy" },
            { "Sterownik", "Sterowniki" },
            { "Widok",     "Edytor" },
            { "Dane",      "Dane" },
            { "Preset",    "Dane" },
            { "UI",        "UI" },
            { "Wrog",      "Wrogowie" },
            { "Gracz",     "Gracz" }
        };

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/AutoKategoryzator")]

    public static void autoKategoryzator()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new()
            {
                "# 📂 Proponowane przeniesienia plików",
                ""
            };

            int licznik = 0;

            foreach (string plik in pliki)
            {
                string relPath = plik.Replace("\\", "/").Replace("Assets/Scripts/", "");
                string folderAktualny = Path.GetDirectoryName(relPath).Replace("\\", "/");
                string nazwaPliku = Path.GetFileName(plik);

                foreach (var reguła in regułyFolderów)
                {
                    if (nazwaPliku.Contains(reguła.Key) && !folderAktualny.Contains(reguła.Value))
                    {
                        string propozycja = $"➡️ `{nazwaPliku}` powinien być w: `Scripts/{reguła.Value}/` (jest: `Scripts/{folderAktualny}/`)";
                        raport.Add(propozycja);
                        licznik++;
                        break;
                    }
                }
            }

            if (licznik == 0)
            {
                raport.Add("✅ Wszystkie pliki znajdują się w odpowiednich folderach.");
            }

            raport.Sort();
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);

            Debug.Log($"📦 AutoKategoryzator: {licznik} plików do przeniesienia → {outputPath}");
            AssetDatabase.Refresh();
        }
    }
}
