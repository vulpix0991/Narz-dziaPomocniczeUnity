// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy nowe pliki .cs zgodne z ZASADY_AI.md przez interfejs okienkowy
// Powiązane: struktura projektu, automatyzacja, porządek

using UnityEditor;
using UnityEngine;
using System.IO;

namespace Narzędzia.Heightmap.Edytor
{
    public class KreatorNowejKlasy : EditorWindow
    {
        private string nazwaKlasy = "NowaKlasa";
        private string folder = "Pędzle"; // domyślny podfolder
        private TypKlasy typ = TypKlasy.MonoBehaviour;

        private enum TypKlasy
        {
            MonoBehaviour,
            ScriptableObject,
            StaticTool,
            Editor,
            Test
        }

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/Kreator nowej klasy...")]
        public static void OtwórzOkno()
        {
            GetWindow<KreatorNowejKlasy>("Kreator Nowej Klasy");
        }

        private void OnGUI()
        {
            GUILayout.Label("🧙 Kreator nowej klasy", EditorStyles.boldLabel);
            nazwaKlasy = EditorGUILayout.TextField("Nazwa klasy", nazwaKlasy);
            folder = EditorGUILayout.TextField("Folder docelowy (np. Pędzle, GPU)", folder);
            typ = (TypKlasy)EditorGUILayout.EnumPopup("Typ klasy", typ);

            GUILayout.Space(10);
            if (GUILayout.Button("📦 Utwórz plik"))
            {
                GenerujPlik();
            }
        }

        private void GenerujPlik()
        {
            string basePath = $"Assets/Scripts/{folder}";
            Directory.CreateDirectory(basePath);

            string filePath = Path.Combine(basePath, nazwaKlasy + ".cs");

            if (File.Exists(filePath))
            {
                Debug.LogWarning($"⚠️ Plik już istnieje: {filePath}");
                return;
            }

            string inheritance = typ switch
            {
                TypKlasy.MonoBehaviour => "MonoBehaviour",
                TypKlasy.ScriptableObject => "ScriptableObject",
                TypKlasy.Editor => "EditorWindow",
                TypKlasy.StaticTool => "",
                TypKlasy.Test => "",
                _ => ""
            };

            string klasaHeader = $@"// Autor: AI (na żądanie Vulpixa)
// Cel: TODO: Opisz cel klasy {nazwaKlasy}
// Powiązane: TODO: Wymień prefab/scenę/system

using UnityEngine;
using UnityEditor;

namespace Narzędzia.Heightmap.{folder}
{{
    {(typ == TypKlasy.StaticTool ? "public static class" : "public class")} {nazwaKlasy}" +
    (string.IsNullOrEmpty(inheritance) ? "" : $" : {inheritance}") + @"
    {
    }
}}";

            File.WriteAllText(filePath, klasaHeader);
            AssetDatabase.Refresh();
            Debug.Log($"✅ Utworzono nową klasę: {filePath}");
        }
    }
}
