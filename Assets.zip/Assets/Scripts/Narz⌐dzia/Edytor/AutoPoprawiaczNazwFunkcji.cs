﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Automatycznie zmienia metody "Uruchom()" na unikalne, zgodne z nazwą klasy
// Powiązane: SRP, duplikacja metod, MenuItem, refaktoryzacja narzędzi edytora

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Edytor
{
    public static class AutoPoprawiaczNazwFunkcji
    {
        private const string folderBazowy = "Assets/Scripts/Narzędzia";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Auto-popraw nazwy metod Uruchom()")]
        public static void AutoPoprawNazwyFunkcji()
        {
            if (!Directory.Exists(folderBazowy))
            {
                Debug.LogError($"❌ Folder '{folderBazowy}' nie istnieje.");
                return;
            }

            string[] pliki = Directory.GetFiles(folderBazowy, "*.cs", SearchOption.AllDirectories);
            int licznikZmienionych = 0;
            List<string> plikiZmienione = new();

            foreach (string sciezkaPliku in pliki)
            {
                string zawartosc = File.ReadAllText(sciezkaPliku);

                Match matchKlasa = Regex.Match(zawartosc, @"public\s+static\s+class\s+(\w+)");
                if (!matchKlasa.Success)
                {
                    Debug.Log($"⏭️ Pominięto (brak klasy static): {sciezkaPliku}"); // DEBUG
                    continue;
                }

                string nazwaKlasy = matchKlasa.Groups[1].Value;
                string nowaNazwaMetody = GenerujNazweMetody(nazwaKlasy);

                // Sprawdź czy już jest poprawnie
                if (Regex.IsMatch(zawartosc, @$"public\s+static\s+void\s+{nowaNazwaMetody}\s*\("))
                {
                    Debug.Log($"✅ Już poprawnie nazwane: {sciezkaPliku}"); // DEBUG
                    continue;
                }

                // Szukaj i zamień metodę Uruchom()
                bool znaleziono = Regex.IsMatch(zawartosc, @"public\s+static\s+void\s+Uruchom\s*\(");
                if (!znaleziono)
                {
                    Debug.Log($"ℹ️ Brak metody Uruchom() w: {sciezkaPliku}"); // DEBUG
                    continue;
                }

                string oryginalna = zawartosc;

                // Zamień metodę + opcjonalny MenuItem
                zawartosc = Regex.Replace(zawartosc,
                    @"(\[MenuItem\([^\]]+\)\]\s*\n)?\s*public\s+static\s+void\s+Uruchom\s*\(",
                    m =>
                    {
                        string menu = m.Groups[1].Value;
                        string nowyMenu = !string.IsNullOrEmpty(menu)
                            ? menu.Replace("Uruchom", nowaNazwaMetody)
                            : "";

                        Debug.Log($"🔧 Zmieniam w {sciezkaPliku}: Uruchom() → {nowaNazwaMetody}"); // DEBUG
                        return $"{nowyMenu}\n    public static void {nowaNazwaMetody}(";
                    });

                if (zawartosc != oryginalna)
                {
                    File.WriteAllText(sciezkaPliku, zawartosc);
                    plikiZmienione.Add(Path.GetFileName(sciezkaPliku));
                    licznikZmienionych++;
                }
            }

            if (licznikZmienionych == 0)
                Debug.Log("ℹ️ Nie znaleziono żadnych metod do poprawienia.");
            else
            {
                Debug.Log($"✅ AutoPoprawiaczNazwFunkcji: zmodyfikowano {licznikZmienionych} plików:");
                foreach (var p in plikiZmienione)
                    Debug.Log($"🟢 {p}");
            }
        }

        private static string GenerujNazweMetody(string nazwaKlasy)
        {
            if (string.IsNullOrWhiteSpace(nazwaKlasy))
                return "uruchomienieNieznanejFunkcji";

            return char.ToLower(nazwaKlasy[0]) + nazwaKlasy.Substring(1);
        }
    }
}
