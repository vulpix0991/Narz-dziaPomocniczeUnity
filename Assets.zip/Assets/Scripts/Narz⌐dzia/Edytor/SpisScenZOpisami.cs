// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy spis wszystkich scen .unity wraz z opisem i klasyfikacją (TEST🗃️ / produkcja)
// Powiązane: dokumentacja, struktura projektu, kontrola produkcji

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Edytor
{
    public static class SpisScenZOpisami
    {
        private const string outputPath = "Assets/Dokumentacja/spis_scen.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/SpisScenZOpisami")]

    public static void spisScenZOpisami()
        {
            string[] pliki = Directory.GetFiles("Assets", "*.unity", SearchOption.AllDirectories);
            List<string> raport = new();

            raport.Add("# 🎬 Spis scen w projekcie\n");

            foreach (string path in pliki)
            {
                string relPath = path.Replace("Assets/", "").Replace("\\", "/");
                string nazwa = Path.GetFileName(path);

                string komentarz = ZnajdzKomentarz(path);

                raport.Add($"- `{relPath}` {komentarz}");
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);
            AssetDatabase.Refresh();

            Debug.Log($"🎬 Wygenerowano spis scen → {outputPath}");
        }

        private static string ZnajdzKomentarz(string path)
        {
            string metaPath = path + ".meta";
            if (!File.Exists(metaPath)) return "";

            string[] meta = File.ReadAllLines(metaPath);
            foreach (string linia in meta)
            {
                if (linia.Contains("//"))
                {
                    return "– " + linia.Trim().Substring(linia.IndexOf("//"));
                }
            }

            return "";
        }
    }
}
