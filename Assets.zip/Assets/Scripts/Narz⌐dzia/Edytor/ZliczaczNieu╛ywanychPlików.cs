// Autor: AI (na żądanie Vulpixa)
// Cel: Wyszukuje potencjalnie nieużywane pliki: .cs, .prefab, .json, .shader itp.
// Powiązane: porządki w repozytorium, debug, optymalizacja

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace Narzędzia.Heightmap.Edytor
{
    public static class ZliczaczNieużywanychPlików
    {
        private const string outputPath = "Assets/Dokumentacja/nieużywane_pliki.md";
        private static readonly string[] rozszerzenia = { ".cs", ".json", ".shader", ".asset", ".png", ".prefab" };
        private static readonly string[] folderyDoPominięcia = { "/Editor/", "/Plugins/", "/Packages/", "/StreamingAssets/" };

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/Zliczacz nieużywanych plików")]
        public static void zliczaczNieużywanychPlików()
        {
            if (!Directory.Exists("Assets"))
            {
                Debug.LogError("❌ Nie znaleziono folderu Assets – nie można wykonać skanowania.");
                return;
            }

            Debug.Log("🧮 ZliczaczNieużywanychPlików: rozpoczęto analizę...");

            List<string> potencjalnieNieużywane = new();
            List<string> wszystkiePliki = new();

            try
            {
                wszystkiePliki = Directory.GetFiles("Assets", "*.*", SearchOption.AllDirectories)
                    .Where(f =>
                        !f.EndsWith(".meta") &&
                        rozszerzenia.Contains(Path.GetExtension(f).ToLower()) &&
                        !folderyDoPominięcia.Any(fod => f.Replace("\\", "/").Contains(fod))
                    )
                    .Select(p => p.Replace("\\", "/"))
                    .ToList();
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas pobierania plików: {ex.Message}");
                return;
            }

            // Sczytaj wszystkie pliki jako tekst – bez Assets, tylko skrypty i pliki tekstowe
            List<string> plikiTekstowe = Directory.GetFiles("Assets", "*.*", SearchOption.AllDirectories)
                .Where(p =>
                    p.EndsWith(".cs") || p.EndsWith(".shader") || p.EndsWith(".json") ||
                    p.EndsWith(".asmdef") || p.EndsWith(".uxml") || p.EndsWith(".uss"))
                .Select(p => p.Replace("\\", "/"))
                .ToList();

            string allText = "";
            foreach (var path in plikiTekstowe)
            {
                try
                {
                    allText += File.ReadAllText(path) + "\n";
                }
                catch { /* ignoruj pliki niedostępne */ }
            }

            foreach (string plik in wszystkiePliki)
            {
                string nazwa = Path.GetFileNameWithoutExtension(plik);
                if (!allText.Contains(nazwa))
                {
                    string relPath = plik.Replace("Assets/", "");
                    potencjalnieNieużywane.Add($"❌ `{relPath}`");
                }
            }

            List<string> raport = new();
            raport.Add("# 🧹 Nieużywane pliki w projekcie\n");

            if (potencjalnieNieużywane.Count == 0)
            {
                raport.Add("✅ Nie znaleziono potencjalnie nieużywanych plików.");
            }
            else
            {
                raport.Add($"⚠ Znaleziono {potencjalnieNieużywane.Count} plików, które nie są referencjami w kodzie:\n");
                raport.AddRange(potencjalnieNieużywane.OrderBy(p => p));
            }

            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
                File.WriteAllLines(outputPath, raport, Encoding.UTF8);
                AssetDatabase.Refresh();
                Debug.Log($"✅ Zakończono skanowanie. Raport → {outputPath}");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"❌ Nie udało się zapisać raportu: {ex.Message}");
            }
        }
    }
}
