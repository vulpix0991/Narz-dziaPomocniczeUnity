// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy spis katalogów i plików z wagą lub liczbą linii kodu
// Powiązane: analiza struktury, snapshoty, AI, refaktoryzacja

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Linq;

namespace Narzędzia.Heightmap.Struktura
{
    public static class StrukturaKatalogówDoTXT
    {
        private const string outputPath = "Assets/Dokumentacja/struktura_katalogów.txt";

        private static int liczbaFolderów = 0;
        private static int liczbaPlików = 0;
        private static long sumaBajtów = 0;

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Utwórz strukturę folderów")]

    public static void strukturaKatalogówDoTXT()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));

            using StreamWriter writer = new(outputPath);
            writer.WriteLine("/Assets/");
            PrzejdźRekursywnie("Assets", writer, 1);
            writer.WriteLine();
            writer.WriteLine($"📦 Suma: {liczbaFolderów} folderów, {liczbaPlików} plików, {(sumaBajtów / 1024f):F1} KB");

            writer.Close();
            AssetDatabase.Refresh();
            Debug.Log($"📁 Wygenerowano strukturę katalogów → {outputPath}");
        }

        private static void PrzejdźRekursywnie(string katalog, StreamWriter writer, int poziom)
        {
            string prefix = new string(' ', poziom * 2);

            var katalogi = Directory.GetDirectories(katalog).OrderBy(d => d).ToList();
            var pliki = Directory.GetFiles(katalog)
                .Where(p => !p.EndsWith(".meta") && !p.EndsWith(".csproj") && !p.EndsWith(".unitypackage") && !p.EndsWith(".DS_Store"))
                .OrderBy(p => p)
                .ToList();

            foreach (string dir in katalogi)
            {
                string nazwa = Path.GetFileName(dir);
                writer.WriteLine($"{prefix}📁 {nazwa}/");
                liczbaFolderów++;
                PrzejdźRekursywnie(dir, writer, poziom + 1);
            }

            foreach (string plik in pliki)
            {
                string nazwa = Path.GetFileName(plik);
                string typ = Path.GetExtension(plik).Replace(".", "").ToLower();
                FileInfo info = new FileInfo(plik);
                string dodatek = "";

                if (typ == "cs")
                {
                    try
                    {
                        int linie = File.ReadAllLines(plik).Length;
                        dodatek = $"{typ}, {linie} linii";
                    }
                    catch
                    {
                        dodatek = $"{typ}, ?";
                    }
                }
                else
                {
                    dodatek = $"{typ}, {(info.Length / 1024f):F1} KB";
                }

                writer.WriteLine($"{prefix}📄 {nazwa} [{dodatek}]");
                liczbaPlików++;
                sumaBajtów += info.Length;
            }
        }
    }
}
