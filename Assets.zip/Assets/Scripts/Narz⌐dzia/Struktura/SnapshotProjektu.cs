// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy pełen snapshot struktury projektu w formacie .json i .txt
// Powiązane: audyt, analiza, porównania, backup, wizualizacja systemu

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Narzędzia.Heightmap.Struktura
{
    public static class SnapshotProjektu
    {
        private const string jsonPath = "Assets/Dokumentacja/snapshot_struktury.json";
        private const string txtPath = "Assets/Dokumentacja/snapshot_struktury.txt";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Snapshot struktury projektu")]

    public static void snapshotProjektu()
        {
            string[] wszystkie = Directory.GetFileSystemEntries("Assets", "*", SearchOption.AllDirectories);
            List<Entry> wpisy = new();
            List<string> txtRaport = new();

            int sumaFolderów = 0;
            int sumaPlików = 0;
            long sumaBajtów = 0;

            foreach (string ścieżka in wszystkie)
            {
                if (ścieżka.Contains("/Editor/") || ścieżka.EndsWith(".meta") || ścieżka.EndsWith(".csproj") || ścieżka.EndsWith(".unitypackage"))
                    continue;

                FileInfo info = new FileInfo(ścieżka);
                bool isFolder = Directory.Exists(ścieżka);

                string typ = isFolder ? "folder" : Path.GetExtension(ścieżka).Replace(".", "").ToLower();
                string relPath = ścieżka.Replace("\\", "/").Replace("Assets/", "");

                int bajty = isFolder ? 0 : (int)info.Length;
                string czas = info.Exists ? info.LastWriteTime.ToString("yyyy-MM-dd HH:mm") : "-";

                wpisy.Add(new Entry
                {
                    sciezka = relPath,
                    typ = string.IsNullOrEmpty(typ) ? "inny" : typ,
                    bajty = bajty,
                    czas = czas
                });

                txtRaport.Add($"{typ.PadRight(8)} {bajty.ToString().PadLeft(8)} B  {czas}  {relPath}");

                if (isFolder) sumaFolderów++;
                else
                {
                    sumaPlików++;
                    sumaBajtów += bajty;
                }
            }

            // Sortuj według ścieżki
            wpisy = wpisy.OrderBy(e => e.sciezka).ToList();
            txtRaport = txtRaport.OrderBy(l => l).ToList();

            // Dodaj podsumowanie na końcu
            txtRaport.Add("");
            txtRaport.Add($"📦 Suma: {sumaPlików} plików, {sumaFolderów} folderów, {(sumaBajtów / 1024f):F1} KB");

            // Zapis
            Directory.CreateDirectory(Path.GetDirectoryName(jsonPath));
            File.WriteAllText(jsonPath, JsonUtility.ToJson(new Container { wpisy = wpisy }, true));
            File.WriteAllLines(txtPath, txtRaport);

            AssetDatabase.Refresh();
            Debug.Log($"📦 Snapshot struktury zapisany: {jsonPath} + {txtPath}");
        }

        [System.Serializable]
        private class Entry
        {
            public string sciezka;
            public string typ;
            public int bajty;
            public string czas;
        }

        [System.Serializable]
        private class Container
        {
            public List<Entry> wpisy;
        }
    }
}
