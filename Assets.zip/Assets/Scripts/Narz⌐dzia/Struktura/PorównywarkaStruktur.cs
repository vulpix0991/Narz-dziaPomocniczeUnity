// Autor: AI (na żądanie Vulpixa)
// Cel: Porównuje strukturę folderów projektu i tworzy raport różnic
// Powiązane: snapshoty, kopie zapasowe, analiza zmian

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Narzędzia.Heightmap.Struktura
{
    public static class PorównywarkaStruktur
    {
        private const string folderA = "Assets/";
        private const string folderB = "Kopie/2025-07-10/";
        private const string raportMd = "Assets/Dokumentacja/porównanie_struktur.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/PorównywarkaStruktur")]
        public static void porównywarkaStruktur()
        {
            if (!Directory.Exists(folderA) || !Directory.Exists(folderB))
            {
                Debug.LogWarning("⚠️ Jeden z folderów nie istnieje. Sprawdź:\n" +
                                 $"- folderA: {folderA}\n" +
                                 $"- folderB: {folderB}");
                return;
            }

            List<string> plikiA = Directory.GetFiles(folderA, "*.*", SearchOption.AllDirectories)
                .Where(p => !p.EndsWith(".meta"))
                .Select(p => p.Replace("\\", "/").Replace(folderA, ""))
                .ToList();

            List<string> plikiB = Directory.GetFiles(folderB, "*.*", SearchOption.AllDirectories)
                .Where(p => !p.EndsWith(".meta"))
                .Select(p => p.Replace("\\", "/").Replace(folderB, ""))
                .ToList();

            List<string> raport = new();
            raport.Add("# 🧾 Porównanie struktury folderów\n");

            var usunięte = new List<string>();
            var przeniesione = new List<string>();
            var dodane = new List<string>();

            foreach (string plik in plikiA)
            {
                if (!plikiB.Contains(plik))
                {
                    string nazwa = Path.GetFileName(plik);
                    if (plikiB.Any(p => Path.GetFileName(p) == nazwa))
                        przeniesione.Add($"🟡 Przeniesiono: `{plik}`");
                    else
                        usunięte.Add($"🔴 Usunięto: `{plik}`");
                }
            }

            foreach (string plik in plikiB)
            {
                if (!plikiA.Contains(plik))
                {
                    string nazwa = Path.GetFileName(plik);
                    if (!plikiA.Any(p => Path.GetFileName(p) == nazwa))
                        dodane.Add($"🟢 Nowy: `{plik}`");
                }
            }

            if (usunięte.Count == 0 && przeniesione.Count == 0 && dodane.Count == 0)
            {
                raport.Add("✅ Brak różnic między folderami.");
            }
            else
            {
                raport.AddRange(usunięte.OrderBy(x => x));
                raport.AddRange(przeniesione.OrderBy(x => x));
                raport.AddRange(dodane.OrderBy(x => x));
            }

            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(raportMd));
                File.WriteAllLines(raportMd, raport);
                AssetDatabase.Refresh();
                Debug.Log($"📄 Porównanie zakończone → {raportMd}");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"❌ Nie udało się zapisać raportu: {ex.Message}");
            }
        }
    }
}
