// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: MenuItem "Narzędzia/Narzędzia_pomocnicze/Walidacja/Validator projektu"
// ⚠️ BŁĘDY: brak namespace, brak komentarza STATUS, logika w Update(), użycie GameObject.Find()
// 🔗 UNITY: używa AssetDatabase, działa tylko w edytorze, generuje .md do folderu DOKUMENTACJA

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace NARZĘDZIA.WALIDACJA
{
    public static class VALIDATOR_PLIKÓW_HEIGHTMAPY
    {
        private const string ŚCIEŻKA_WYNIKU = "Assets/DOKUMENTACJA/CHECKLISTY_BŁĘDÓW.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Validator projektu")]
        public static void WALIDUJ_PROJEKT()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);

            List<string> błędy = new()
            {
                "# ❗ Lista błędów i ostrzeżeń w kodzie\n"
            };

            foreach (string ścieżka in pliki)
            {
                string[] linie = File.ReadAllLines(ścieżka);
                string nazwa = Path.GetFileName(ścieżka);

                int liczbaKlas = 0;
                bool maNamespace = false;
                bool maNagłówekAI = false;
                bool maNagłówekTechniczny = false;
                bool maSerializable = false;
                bool zawieraUpdate = false;
                bool updateZLogiką = false;

                for (int i = 0; i < linie.Length; i++)
                {
                    string linia = linie[i].Trim();

                    if (linia.StartsWith("namespace ")) maNamespace = true;
                    if (linia.Contains("class ")) liczbaKlas++;
                    if (linia.Contains("[System.Serializable]")) maSerializable = true;
                    if (linia.StartsWith("// Autor:")) maNagłówekAI = true;
                    if (linia.StartsWith("// 📄 STATUS:")) maNagłówekTechniczny = true;
                    if (linia.Contains("GameObject.Find(")) błędy.Add($"🔴 `{nazwa}` → użycie GameObject.Find() w linii {i + 1}");
                    if (linia.Contains("void Update(")) zawieraUpdate = true;

                    if (zawieraUpdate && (linia.Contains("Input.") || linia.Contains("GetKey") || linia.Contains("if(")))
                        updateZLogiką = true;
                }

                if (!maNamespace)
                    błędy.Add($"❌ `{nazwa}` → brak namespace");

                if (!maNagłówekAI)
                    błędy.Add($"❌ `{nazwa}` → brak nagłówka AI (// Autor:)");

                if (!maNagłówekTechniczny)
                    błędy.Add($"❌ `{nazwa}` → brak komentarza STATUS");

                if (!maSerializable && nazwa.StartsWith("DANE"))
                    błędy.Add($"❌ `{nazwa}` → brak [System.Serializable]");

                if (liczbaKlas > 1)
                    błędy.Add($"⚠️ `{nazwa}` → więcej niż jedna klasa w pliku");

                if (updateZLogiką)
                    błędy.Add($"🔶 `{nazwa}` → logika w Update()");
            }

            if (błędy.Count == 1)
                błędy.Add("✅ Brak błędów zgodności z zasadami projektu");

            Directory.CreateDirectory(Path.GetDirectoryName(ŚCIEŻKA_WYNIKU));
            File.WriteAllLines(ŚCIEŻKA_WYNIKU, błędy);
            AssetDatabase.Refresh();

            Debug.Log($"🛡 Walidacja zakończona → {ŚCIEŻKA_WYNIKU}");
        }
    }
}
