// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: MenuItem "Narzędzia/Narzędzia_pomocnicze/Walidacja/ChecklistyZgodności"
// ⚠️ BŁĘDY: brak folderu Systemy, brak powiązanych klas, brak prefabów
// 🔗 UNITY: działa w edytorze, generuje checklistę .md w folderze DOKUMENTACJA

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace NARZĘDZIA.WALIDACJA
{
    public static class CHECKLISTY_ZGODNOŚCI
    {
        private const string ŚCIEŻKA_WYNIKU = "Assets/DOKUMENTACJA/CHECKLISTY_SYSTEMÓW.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/ChecklistyZgodności")]
        public static void GENERUJ_CHECKLISTĘ()
        {
            string folderSystemy = "Assets/Scripts/Systemy/";
            if (!Directory.Exists(folderSystemy))
            {
                Debug.LogWarning("❌ Brak folderu: Scripts/Systemy/");
                return;
            }

            List<string> raport = new()
            {
                "# ✅ Checklisty zgodności systemów\n",
                "| System | Dane | GUI | Sterownik | Prefab |",
                "|--------|------|-----|------------|--------|"
            };

            string[] plikiSystemów = Directory.GetFiles(folderSystemy, "SYSTEM_*.cs", SearchOption.AllDirectories);

            foreach (string ścieżka in plikiSystemów)
            {
                string nazwaSystemu = Path.GetFileNameWithoutExtension(ścieżka).Replace("SYSTEM_", "");

                // Ścieżki powiązanych plików
                string danePath = $"Assets/Scripts/Dane/DANE_{nazwaSystemu}.cs";
                string guiPath = $"Assets/Scripts/GUI/GUI_{nazwaSystemu}.cs";
                string sterPath = $"Assets/Scripts/Sterowniki/STEROWNIK_{nazwaSystemu}.cs";
                string prefabPath = $"Assets/PREFABY/{nazwaSystemu}.prefab";

                string daneOK = File.Exists(danePath) ? "✔" : "❌";
                string guiOK = File.Exists(guiPath) ? "✔" : "❌";
                string sterOK = File.Exists(sterPath) ? "✔" : "❌";
                string prefabOK = File.Exists(prefabPath) ? "✔" : "❌";

                raport.Add($"| `{nazwaSystemu}` | {daneOK} | {guiOK} | {sterOK} | {prefabOK} |");
            }

            if (plikiSystemów.Length == 0)
            {
                raport.Add("\n⚠️ Nie znaleziono żadnych plików `SYSTEM_*.cs`.");
            }

            Directory.CreateDirectory(Path.GetDirectoryName(ŚCIEŻKA_WYNIKU));
            File.WriteAllLines(ŚCIEŻKA_WYNIKU, raport);
            AssetDatabase.Refresh();

            Debug.Log($"📋 Wygenerowano checklistę systemów → {ŚCIEŻKA_WYNIKU}");
        }
    }
}
