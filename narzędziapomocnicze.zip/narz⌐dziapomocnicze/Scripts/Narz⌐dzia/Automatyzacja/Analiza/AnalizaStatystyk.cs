﻿// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: wywoływany przez narzędzia eksportujące scenę (ParserHierarchii, EksportSceny)
// ⚠️ BŁĘDY: brak folderu Eksport, pusty plik, brak ParserHierarchii lub RaportMarkdown
// 🔗 UNITY: analizuje eksport tekstowy sceny, generuje markdown z podsumowaniem

using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Narzędzia.Automatyzacja.Analiza
{
    public static class AnalizaStatystyk
    {
        public static void Analizuj()
        {
            try
            {
                string folder = Path.Combine(Application.dataPath, "../Eksport");

                if (!Directory.Exists(folder))
                {
                    Debug.LogWarning("⚠️ Folder Eksport/ nie istnieje.");
                    return;
                }

                string[] pliki = Directory.GetFiles(folder, "HierarchiaDebug_*.txt");
                if (pliki.Length == 0)
                {
                    Debug.LogWarning("⚠️ Brak plików do analizy.");
                    return;
                }

                string ostatni = pliki.OrderByDescending(File.GetLastWriteTime).First();
                string scena = Path.GetFileNameWithoutExtension(ostatni).Replace("HierarchiaDebug_", "");
                string wynik = Path.Combine(folder, $"HierarchiaDebug_{scena}_Statystyki.md");

                Debug.Log($"📥 Wczytywanie pliku: {ostatni}");

                string[] linie = File.ReadAllLines(ostatni);
                if (linie == null || linie.Length == 0)
                {
                    Debug.LogError("❌ Plik eksportu jest pusty lub nieczytelny.");
                    return;
                }

                var dane = ParserHierarchii.Przetwórz(linie);
                RaportMarkdown.Generuj(dane, scena, wynik);

                Debug.Log($"✅ Raport .md wygenerowany: {wynik}");
                AssetDatabase.Refresh();
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas analizy pliku hierarchii: {ex.Message}");
            }
        }
    }
}
