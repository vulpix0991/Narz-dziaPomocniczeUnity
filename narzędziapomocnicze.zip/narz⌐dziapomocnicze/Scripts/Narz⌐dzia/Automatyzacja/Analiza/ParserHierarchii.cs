﻿// 📄 STATUS: DO ROZDZIELENIA
// 🧩 INTERFEJS: wywoływany przez AnalizaStatystyk.Analizuj()
// ⚠️ BŁĘDY: błąd w linii tekstu, nieznany format
// 🔗 UNITY: analizuje pliki z eksportu sceny (.txt), przekazuje dane do RaportMarkdown

using System;
using System.Collections.Generic;
using UnityEngine;

namespace Narzędzia.Automatyzacja.Analiza
{
    public static class ParserHierarchii
    {
        public static DaneStatystyk Przetwórz(string[] linie)
        {
            var dane = new DaneStatystyk();
            string aktualny = "";
            const string prefixGameObject = "- GameObject:";

            for (int i = 0; i < linie.Length; i++)
            {
                string linia = linie[i];
                string trimmed = linia.Trim();

                try
                {
                    if (string.IsNullOrWhiteSpace(trimmed))
                    {
                        aktualny = "";
                        continue;
                    }

                    if (trimmed.StartsWith(prefixGameObject))
                    {
                        dane.Obiekty++;
                        aktualny = trimmed[prefixGameObject.Length..].Trim();

                        if (dane.WidzianeNazwy.Contains(aktualny))
                            dane.DuplikatyNazw++;
                        else
                            dane.WidzianeNazwy.Add(aktualny);
                    }
                    else if (trimmed.Contains("⚠️ Brakujący komponent"))
                    {
                        dane.NullKomponenty++;
                        if (!string.IsNullOrEmpty(aktualny))
                            dane.OstatnieBłęty[aktualny] = "⚠️ Brakujący komponent";
                    }
                    else if (trimmed.StartsWith("▸"))
                    {
                        dane.Komponenty++;
                        string typ = trimmed[1..].Trim();

                        if (typ == "AudioSource") dane.AudioBezClip++;
                        if (typ == "Animator") dane.AnimatorBezKontrolera++;
                        if (typ == "AudioListener") dane.AudioListenerCount++;
                        if (typ == "EventSystem") dane.EventSystemCount++;
                    }
                    else if (trimmed.StartsWith("Tag: Untagged"))
                    {
                        dane.Untagged++;
                        if (!string.IsNullOrEmpty(aktualny))
                            dane.OstatnieBłęty[aktualny] = "Tag = Untagged";
                    }
                    else if (trimmed.StartsWith("Layer: Default"))
                    {
                        dane.DefaultLayer++;
                        if (!string.IsNullOrEmpty(aktualny))
                            dane.OstatnieBłęty[aktualny] = "Layer = Default";
                    }
                    else if (trimmed.Contains("Komponenty:") && trimmed.EndsWith("0"))
                    {
                        dane.BezKomponentów++;
                    }
                    else if (trimmed.StartsWith("ActiveSelf: False"))
                    {
                        dane.NieaktywneObiekty++;
                        if (!string.IsNullOrEmpty(aktualny))
                            dane.OstatnieBłęty[aktualny] = "Obiekt nieaktywny";
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"❌ Błąd parsera w linii {i}: \"{trimmed}\" – {ex.Message}");
                }
            }

            return dane;
        }
    }
}
