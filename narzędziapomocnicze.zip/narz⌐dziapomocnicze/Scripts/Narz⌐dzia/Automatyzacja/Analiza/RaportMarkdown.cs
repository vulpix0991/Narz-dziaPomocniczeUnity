﻿// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: wywoływany z poziomu narzędzi analizujących (ParserHierarchii, AnalizaStatystyk)
// ⚠️ BŁĘDY: błąd dostępu do pliku, brak danych wejściowych
// 🔗 UNITY: współpracuje z klasą DaneStatystyk, generuje raport .md w folderze DOKUMENTACJA

using System;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Narzędzia.Automatyzacja.Analiza
{
    public static class RaportMarkdown
    {
        public static void Generuj(DaneStatystyk dane, string scena, string ścieżka = "Assets/DOKUMENTACJA/ANALIZA_HIERARCHII.md")
        {
            try
            {
                var katalog = Path.GetDirectoryName(ścieżka);
                if (!string.IsNullOrEmpty(katalog))
                    Directory.CreateDirectory(katalog);

                using var sw = new StreamWriter(ścieżka, false, Encoding.UTF8);

                // Nagłówek raportu
                sw.WriteLine($"# 🧪 Raport: HierarchiaDebug – scena: `{scena}`");
                sw.WriteLine($"Data: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n");

                // Statystyki ogólne
                sw.WriteLine("## 📊 Statystyki ogólne");
                sw.WriteLine($"- 🎮 Liczba GameObjectów: **{dane.Obiekty}**");
                sw.WriteLine($"- 🧩 Liczba komponentów: **{dane.Komponenty}**");
                sw.WriteLine($"- ⚠️ Null komponentów: **{dane.NullKomponenty}**");
                sw.WriteLine($"- ⛔ Obiekty bez komponentów: **{dane.BezKomponentów}**\n");

                // Problemy logiczne
                sw.WriteLine("## 🚨 Problemy potencjalne:");
                sw.WriteLine($"- 🔇 AudioSource bez clip: **{dane.AudioBezClip}**");
                sw.WriteLine($"- 🎭 Animator bez kontrolera: **{dane.AnimatorBezKontrolera}**");
                sw.WriteLine($"- 🏷️ Untagged: **{dane.Untagged}**");
                sw.WriteLine($"- 🧱 Warstwa Default: **{dane.DefaultLayer}**\n");

                // Diagnostyka systemowa
                sw.WriteLine("## ⚙️ Diagnostyka systemowa:");
                sw.WriteLine($"- 🎧 AudioListener: **{dane.AudioListenerCount}**");
                if (dane.AudioListenerCount > 1)
                    sw.WriteLine("  ⚠️ Więcej niż 1 AudioListener – może powodować problemy");

                sw.WriteLine($"- 🧭 EventSystem: **{dane.EventSystemCount}**");
                if (dane.EventSystemCount == 0)
                    sw.WriteLine("  ⚠️ Brak EventSystem – UI może nie działać\n");

                // Przykładowe błędy
                sw.WriteLine("## 🔍 Przykładowe obiekty z problemami:");
                if (dane.OstatnieBłęty == null || dane.OstatnieBłęty.Count == 0)
                {
                    sw.WriteLine("- ✅ Brak wykrytych błędów w obiektach!");
                }
                else
                {
                    foreach (var para in dane.OstatnieBłęty.Reverse().Take(3))
                        sw.WriteLine($"- `{para.Key}` → {para.Value}");
                }

                // Podsumowanie
                sw.WriteLine("\n## 📌 Podsumowanie błędów:");
                int suma = dane.NullKomponenty + dane.BezKomponentów + dane.AudioBezClip +
                           dane.AnimatorBezKontrolera + dane.Untagged + dane.DefaultLayer;

                if (suma == 0)
                    sw.WriteLine("- ✅ Nie wykryto błędów ani ostrzeżeń.");
                else
                    sw.WriteLine($"- ⚠️ Łącznie potencjalnych problemów: **{suma}**");

                sw.WriteLine("\n✅ Analiza zakończona.");

                Debug.Log($"📄 Raport wygenerowany: {ścieżka}");
                UnityEditor.AssetDatabase.Refresh();
            }
            catch (Exception ex)
            {
                Debug.LogError($"❌ Błąd podczas generowania raportu Markdown: {ex.Message}");
            }
        }
    }
}
