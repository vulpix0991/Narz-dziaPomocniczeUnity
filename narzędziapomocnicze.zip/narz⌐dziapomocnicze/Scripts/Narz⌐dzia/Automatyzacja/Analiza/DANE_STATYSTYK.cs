﻿// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: używany przez ParserHierarchii, RaportMarkdown, AnalizaStatystyk
// ⚠️ BŁĘDY: brak danych wejściowych, null w słowniku OstatnieBłędy
// 🔗 UNITY: dane zbierane z plików tekstowych eksportu sceny (eksport hierarchii)

using System.Collections.Generic;

namespace Narzędzia.Automatyzacja.Analiza
{
    public class DaneStatystyk
    {
        // Statystyki obiektów
        public int Obiekty;
        public int Komponenty;
        public int NullKomponenty;
        public int BezKomponentów;

        // Problemy z komponentami
        public int AudioBezClip;
        public int AnimatorBezKontrolera;
        public int Untagged;
        public int DefaultLayer;

        // Diagnostyka systemowa
        public int AudioListenerCount;
        public int EventSystemCount;

        // Dodatkowe wykrycia
        public int NieaktywneObiekty;
        public int DuplikatyNazw;

        // Opis błędów przypisanych do obiektów
        public Dictionary<string, string> OstatnieBłęty = new();

        // Tymczasowy zbiór nazw do sprawdzania duplikatów
        internal HashSet<string> WidzianeNazwy = new();
    }
}
