﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Formatuje dane sceny i obiektów do pliku tekstowego
// Powiązane: ZbieraczHierarchii.cs

using UnityEngine;
using System.Text;
using System;

namespace Heightmap.Narzędzia.Automatyzacja.Eksport
{
    public static class FormatterHierarchii
    {
        public static string Formatuj(string nazwaSceny, GameObject[] rootObiekty)
        {
            var sb = new StringBuilder();

            sb.AppendLine($"// ===========================================");
            sb.AppendLine($"// Eksport hierarchii sceny: {nazwaSceny}");
            sb.AppendLine($"// Data: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"// Obiektów głównych: {rootObiekty?.Length ?? 0}");
            sb.AppendLine($"// ===========================================\n");

            if (rootObiekty == null || rootObiekty.Length == 0)
            {
                sb.AppendLine("// ⚠️ Brak obiektów głównych w scenie."); // DEBUG
                return sb.ToString();
            }

            foreach (var root in rootObiekty)
            {
                try
                {
                    ZbieraczHierarchii.Zbierz(root, 0, sb);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"❌ Błąd podczas zbierania danych obiektu root: {root?.name} → {ex.Message}"); // DEBUG
                    sb.AppendLine($"// ❌ Błąd: {root?.name} – {ex.Message}");
                }
            }

            sb.AppendLine("// ✅ Eksport zakończony pomyślnie.");
            return sb.ToString();
        }
    }
}
