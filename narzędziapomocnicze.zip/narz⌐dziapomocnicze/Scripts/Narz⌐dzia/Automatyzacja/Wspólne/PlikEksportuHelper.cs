﻿// Autor: AI (na żądanie Vulpixa)
// Cel: Buduje ścieżkę pliku eksportu i usuwa stary
// Powiązane: DebugerSceny.cs

using UnityEngine;
using System.IO;
using System;

namespace Heightmap.Narzędzia.Automatyzacja
{
    public static class PlikEksportuHelper
    {
        public static string PrzygotujPlikEksportu(string nazwaSceny)
        {
            string folder = Path.Combine(Application.dataPath, "../Eksport");

            try
            {
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                    Debug.Log("📁 Utworzono folder eksportu: " + folder); // DEBUG
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("❌ Nie można utworzyć folderu Eksport: " + ex.Message); // DEBUG
                return null;
            }

            string sciezka = Path.Combine(folder, $"HierarchiaDebug_{nazwaSceny}.txt");

            try
            {
                if (File.Exists(sciezka))
                {
                    File.Delete(sciezka);
                    Debug.Log("🗑 Usunięto stary plik eksportu: " + sciezka); // DEBUG
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("❌ Nie można usunąć starego pliku: " + ex.Message); // DEBUG
            }

            return sciezka;
        }
    }
}
