// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy pełny indeks prefabów z opisem ich komponentów
// Powiązane: dokumentacja projektu, debugowanie prefabów, analiza zależności

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Narzędzia.Heightmap.Edytor
{
    public static class IndeksPrefabów
    {
        private const string folderPrefabów = "Assets/Prefaby";
        private const string outputPath = "Assets/Dokumentacja/indeks_prefabów.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/IndeksPrefabów")]
        public static void indeksPrefabów()
        {
            if (!Directory.Exists(folderPrefabów))
            {
                Debug.LogWarning($"⚠️ Folder '{folderPrefabów}' nie istnieje – pomijam generowanie indeksu prefabów.");
                return;
            }

            string[] prefabPaths = Directory.GetFiles(folderPrefabów, "*.prefab", SearchOption.AllDirectories);
            if (prefabPaths.Length == 0)
            {
                Debug.Log("ℹ️ Brak prefabów do analizy.");
                return;
            }

            List<string> raport = new();
            raport.Add("# 📇 Indeks prefabów w projekcie\n");
            raport.Add("| Prefab | Komponenty | Missing Script |");
            raport.Add("|--------|------------|----------------|");

            foreach (string path in prefabPaths.OrderBy(p => p))
            {
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null)
                {
                    Debug.LogWarning($"❌ Nie udało się wczytać prefab: {path}");
                    continue;
                }

                string relPath = path.Replace("Assets/", "");
                HashSet<string> komponenty = new();
                bool missingScript = false;

                foreach (var comp in prefab.GetComponentsInChildren<Component>(true))
                {
                    if (comp == null)
                    {
                        missingScript = true;
                        continue;
                    }

                    string type = comp.GetType().Name;
                    if (type.StartsWith("UnityEngine.")) type = type.Replace("UnityEngine.", "");
                    komponenty.Add(type);
                }

                string komponentyStr = komponenty.Count > 0 ? string.Join(", ", komponenty.OrderBy(k => k)) : "-";
                string missingStr = missingScript ? "❗ TAK" : "✅ NIE";

                raport.Add($"| `{relPath}` | {komponentyStr} | {missingStr} |");
            }

            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
                File.WriteAllLines(outputPath, raport);
                AssetDatabase.Refresh();
                Debug.Log($"📇 Wygenerowano indeks prefabów → {outputPath}");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"❌ Błąd zapisu indeksu prefabów: {ex.Message}");
            }
        }
    }
}
