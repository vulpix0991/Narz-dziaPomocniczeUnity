// Autor: AI (na żądanie Vulpixa)
// Cel: Wyszukuje funkcje o identycznym lub bardzo podobnym ciele w wielu plikach
// Powiązane: refaktoryzacja, SRP, porządek w systemie heightmap

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;

namespace Narzędzia.Heightmap.Edytor
{
    public static class SkanerDuplikacjiKodu
    {
        private const string outputPath = "Assets/Dokumentacja/duplikaty_kodu.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/SkanerDuplikacjiKodu")]
        public static void skanerDuplikacjiKodu()
        {
            Debug.Log("🔁 Skanowanie projektu pod kątem duplikatów funkcji...");

            if (!Directory.Exists("Assets/Scripts"))
            {
                Debug.LogWarning("⚠️ Brak folderu: Assets/Scripts");
                return;
            }

            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            Dictionary<string, string> mapaHashy = new(); // klucz = pełna sygnatura z pliku, wartość = hash ciała
            Dictionary<string, List<string>> duplikaty = new(); // hash => lista metod

            foreach (string plik in pliki)
            {
                string[] linie;
                try
                {
                    linie = File.ReadAllLines(plik);
                }
                catch
                {
                    Debug.LogWarning($"⚠️ Nie można odczytać pliku: {plik}");
                    continue;
                }

                string ścieżka = plik.Replace("\\", "/").Replace("Assets/", "");
                string sygnatura = "";
                List<string> ciało = new();
                bool wMetodzie = false;
                int nawiasy = 0;

                for (int i = 0; i < linie.Length; i++)
                {
                    string trimmed = linie[i].Trim();

                    if (Regex.IsMatch(trimmed, @"(public|private|protected|internal)(\s+static)?(\s+async)?(\s+\w+)?\s+[\w\<\>]+\s+\w+\s*\(.*\)\s*"))
                    {
                        sygnatura = trimmed;
                        ciało = new();
                        nawiasy = 0;
                        wMetodzie = true;
                    }

                    if (wMetodzie)
                    {
                        if (!trimmed.StartsWith("//")) ciało.Add(trimmed);
                        nawiasy += trimmed.Count(c => c == '{');
                        nawiasy -= trimmed.Count(c => c == '}');

                        if (nawiasy <= 0)
                        {
                            string tekst = string.Join("", ciało)
                                .Replace(" ", "")
                                .Replace("\t", "")
                                .Replace("\n", "")
                                .Replace("\r", "");

                            string hash = ObliczHash(tekst);
                            string klucz = $"{ścieżka}: {sygnatura}";

                            if (!duplikaty.ContainsKey(hash))
                                duplikaty[hash] = new List<string>();

                            duplikaty[hash].Add(klucz);
                            wMetodzie = false;
                        }
                    }
                }
            }

            List<string> raport = new()
            {
                "# 🔄 Duplikacja kodu – podejrzane powtórzenia",
                ""
            };

            int licznik = 0;
            foreach (var para in duplikaty.Where(p => p.Value.Count > 1))
            {
                var grupy = para.Value;
                raport.Add($"🟥 Duplikat ({grupy.Count} razy):");
                foreach (var wpis in grupy.OrderBy(w => w))
                    raport.Add($"   • `{wpis}`");
                raport.Add("");
                licznik++;
            }

            if (licznik == 0)
                raport.Add("✅ Nie znaleziono powtarzających się funkcji.");

            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
                File.WriteAllLines(outputPath, raport);
                AssetDatabase.Refresh();
                Debug.Log($"✅ Skanowanie zakończone. Raport → {outputPath}");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"❌ Błąd zapisu raportu: {ex.Message}");
            }
        }

        private static string ObliczHash(string tekst)
        {
            using var sha1 = System.Security.Cryptography.SHA1.Create();
            byte[] hash = sha1.ComputeHash(System.Text.Encoding.UTF8.GetBytes(tekst));
            return System.BitConverter.ToString(hash).Replace("-", "").ToLower();
        }
    }
}
