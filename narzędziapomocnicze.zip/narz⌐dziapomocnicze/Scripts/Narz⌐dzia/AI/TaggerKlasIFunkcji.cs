// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: MenuItem "Narzędzia/Narzędzia_pomocnicze/AI/Spis klas z tagami"
// ⚠️ BŁĘDY: brak klasy w pliku, brak nagłówka STATUS, błędna ścieżka
// 🔗 UNITY: działa w edytorze, generuje markdown do folderu DOKUMENTACJA

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace NARZĘDZIA.AI
{
    public static class TAGGER_KLAS_I_FUNKCJI
    {
        private const string ŚCIEŻKA_WYNIKU = "Assets/DOKUMENTACJA/TAGI_KLAS_I_FUNKCJI.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Spis klas z tagami")]
        public static void GENERUJ_TABELĘ_TAGÓW()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new()
            {
                "# 🏷️ Tagi klas i funkcji\n",
                "| Plik | Klasa | Tagi |",
                "|------|-------|------|"
            };

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileName(plik);
                string sciezka = plik.Replace("Assets/", "").Replace("\\", "/");
                string nazwaKlasy = Path.GetFileNameWithoutExtension(plik);

                List<string> tagi = new();

                // Po nazwie klasy
                if (nazwaKlasy.Contains("PĘDZEL")) tagi.Add("[Pędzel]");
                if (nazwaKlasy.Contains("GPU")) tagi.Add("[GPU]");
                if (nazwaKlasy.Contains("TEST")) tagi.Add("[TEST🗃️]");
                if (nazwaKlasy.Contains("EDITOR")) tagi.Add("[Editor]");
                if (nazwaKlasy.Contains("SYSTEM") || nazwaKlasy.Contains("STEROWNIK")) tagi.Add("[System]");
                if (nazwaKlasy.Contains("DANE") || nazwaKlasy.Contains("PRESET")) tagi.Add("[Data]");

                // Po ścieżce
                if (sciezka.Contains("/PĘDZLE/")) tagi.Add("[Pędzel]");
                if (sciezka.Contains("/GPU/")) tagi.Add("[GPU]");
                if (sciezka.Contains("/TESTY/")) tagi.Add("[TEST🗃️]");
                if (sciezka.Contains("/EDYTOR/")) tagi.Add("[Editor]");
                if (sciezka.Contains("/DANE/")) tagi.Add("[Data]");

                // Po zawartości
                foreach (string linia in linie)
                {
                    if (linia.Contains("Debug.Log")) { tagi.Add("[Debug]"); break; }
                    if (linia.Contains(": ScriptableObject")) { tagi.Add("[Data]"); break; }
                    if (linia.StartsWith("// 📄 STATUS:")) tagi.Add("[STATUS:" + linia.Replace("// 📄 STATUS:", "").Trim() + "]");
                }

                string wynik = tagi.Count > 0 ? string.Join(" ", tagi) : "-";
                raport.Add($"| `{nazwaPliku}` | `{nazwaKlasy}` | {wynik} |");
            }

            Directory.CreateDirectory(Path.GetDirectoryName(ŚCIEŻKA_WYNIKU));
            File.WriteAllLines(ŚCIEŻKA_WYNIKU, raport);
            AssetDatabase.Refresh();

            Debug.Log($"🏷️ Wygenerowano tagi klas i funkcji → {ŚCIEŻKA_WYNIKU}");
        }
    }
}
