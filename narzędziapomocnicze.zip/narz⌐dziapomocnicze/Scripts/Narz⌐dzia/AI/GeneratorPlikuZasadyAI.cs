// Autor: AI (na żądanie Vulpixa)
// Cel: Generuje aktualny plik ZASADY_AI.md na podstawie analizy struktury i kodu projektu
// Powiązane: dokumentacja, walidacja, refaktoryzacja, automatyczna kontrola jakości

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;

namespace Narzędzia.Heightmap.AI
{
    public static class GeneratorPlikuZasadyAI
    {
        private const string outputPath = "Assets/ZASADY_AI.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Generuj ZASADY_AI.md")]

    public static void generatorPlikuZasadyAI()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);

            int bezNamespace = 0;
            int bezNagłówka = 0;
            int wieleKlas = 0;
            int gameObjectFind = 0;
            int updateZLogiką = 0;
            int bezSerializable = 0;
            int brakSerializeField = 0;
            int niepoprawnyFolderTestu = 0;
            int bezUnityEngine = 0;
            int bezUnityEditor = 0;

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileName(plik);
                int klasyWPliku = 0;
                bool maNamespace = false;
                bool maNagłówekAI = false;
                bool maSerializable = false;
                bool maUnityEngine = false;
                bool maUnityEditor = false;
                bool updateActive = false;

                foreach (string linia in linie)
                {
                    string trimmed = linia.Trim();

                    if (trimmed.StartsWith("namespace ")) maNamespace = true;
                    if (trimmed.StartsWith("// Autor: AI")) maNagłówekAI = true;
                    if (trimmed.StartsWith("using UnityEngine")) maUnityEngine = true;
                    if (trimmed.StartsWith("using UnityEditor")) maUnityEditor = true;

                    if (trimmed.Contains("[System.Serializable]")) maSerializable = true;
                    if (trimmed.Contains("[SerializeField]")) brakSerializeField++;

                    if (trimmed.Contains("class ")) klasyWPliku++;
                    if (trimmed.Contains("GameObject.Find(")) gameObjectFind++;

                    if (trimmed.Contains("void Update(")) updateActive = true;

                    if (updateActive && (trimmed.Contains("if(") || trimmed.Contains("Input.") || trimmed.Contains("GetKey") || trimmed.Contains("GetAxis")))
                    {
                        updateZLogiką++;
                        updateActive = false;
                    }
                }

                if (!maNamespace) bezNamespace++;
                if (!maNagłówekAI) bezNagłówka++;
                if (klasyWPliku > 1) wieleKlas++;
                if (!maSerializable && nazwaPliku.StartsWith("Dane")) bezSerializable++;
                if (!maUnityEngine) bezUnityEngine++;
                if (!maUnityEditor && plik.Contains("/Edytor/")) bezUnityEditor++;

                if (nazwaPliku.StartsWith("Test") && !plik.Replace("\\", "/").Contains("/Testy/"))
                    niepoprawnyFolderTestu++;
            }

            var raport = new[]
            {
                "# ✅ Raport zgodności z ZASADY_AI.md",
                "",
                $"📦 Przeskanowano `{pliki.Length}` plików `.cs`",
                "",
                $"- Namespace obecny: {(bezNamespace == 0 ? "✅" : $"❌ brak w {bezNamespace} plikach")}",
                $"- Nagłówek AI (`// Autor: AI`) obecny: {(bezNagłówka == 0 ? "✅" : $"❌ brak w {bezNagłówka} plikach")}",
                $"- Jeden plik = jedna klasa: {(wieleKlas == 0 ? "✅" : $"❌ {wieleKlas} plików zawiera wiele klas")}",
                $"- Brak GameObject.Find(): {(gameObjectFind == 0 ? "✅" : $"❌ występuje {gameObjectFind} razy")}",
                $"- Update() bez logiki: {(updateZLogiką == 0 ? "✅" : $"❌ logika w {updateZLogiką} przypadkach")}",
                $"- `[System.Serializable]` dla danych (`Dane*.cs`): {(bezSerializable == 0 ? "✅" : $"❌ brak w {bezSerializable}")}",
                $"- `[SerializeField]` obecne: {(brakSerializeField > 0 ? $"ℹ️ {brakSerializeField} razy" : "✅ brak danych")}",
                $"- `Test*.cs` w folderze `/Testy/`: {(niepoprawnyFolderTestu == 0 ? "✅" : $"❌ {niepoprawnyFolderTestu} poza folderem")}",
                $"- `using UnityEngine` obecne: {(bezUnityEngine == 0 ? "✅" : $"❌ brak w {bezUnityEngine}")}",
                $"- `using UnityEditor` w folderze Edytor/: {(bezUnityEditor == 0 ? "✅" : $"❌ brak w {bezUnityEditor} edytorowych")}",
                "",
                "---",
                "_Wygenerowano automatycznie przez GeneratorPlikuZasadyAI.cs_"
            };

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);
            AssetDatabase.Refresh();

            Debug.Log($"📄 ZASADY_AI.md zaktualizowane → {outputPath}");
        }
    }
}
