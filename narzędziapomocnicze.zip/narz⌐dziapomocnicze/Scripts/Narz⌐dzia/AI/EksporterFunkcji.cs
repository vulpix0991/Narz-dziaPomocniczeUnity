// 📄 STATUS: KOMPLETNY
// 🧩 INTERFEJS: MenuItem "Narzędzia/Narzędzia_pomocnicze/AI/Eksporter funkcji i klas"
// ⚠️ BŁĘDY: brak klasy w pliku, brak komentarza STATUS, błąd zapisu .md
// 🔗 UNITY: edytor Unity, zapis pliku dokumentacyjnego .md do folderu DOKUMENTACJA

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace NARZĘDZIA.AI
{
    public static class EKSPORTER_FUNKCJI
    {
        private const string ŚCIEŻKA_WYNIKU = "Assets/DOKUMENTACJA/FUNKCJE.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Eksporter funkcji i klas")]
        public static void EKSPORTUJ()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new();

            int sumaKlas = 0, sumaMetod = 0, sumaWłaściwości = 0;

            raport.Add("# 📄 Lista klas, metod, właściwości i statusów w projekcie\n");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileName(plik);
                int liczbaKlas = 0, liczbaMetod = 0, liczbaProps = 0;

                raport.Add($"## 📄 {nazwaPliku}");

                // STATUS z nagłówka technicznego
                string status = "";
                foreach (string linia in linie)
                {
                    if (linia.Trim().StartsWith("// 📄 STATUS:"))
                    {
                        status = linia.Trim().Replace("// 📄 STATUS:", "").Trim();
                        break;
                    }
                }
                if (!string.IsNullOrEmpty(status))
                    raport.Add($"🧾 STATUS: `{status}`");

                for (int i = 0; i < linie.Length; i++)
                {
                    string linia = linie[i].Trim();

                    // Atrybuty
                    if (Regex.IsMatch(linia, @"^\[.*\]"))
                    {
                        raport.Add($"🔖 Atrybut: `{linia}`");
                        continue;
                    }

                    // Klasa
                    if (Regex.IsMatch(linia, @"\b(public|internal|private)?\s*(static\s*)?class\s+\w+"))
                    {
                        raport.Add($"🧩 Klasa: `{linia}`");
                        liczbaKlas++;
                        continue;
                    }

                    // Konstruktor
                    if (Regex.IsMatch(linia, @"\b(public|internal|private)?\s+\w+\s*\(.*\)\s*{?") && linia.Contains(nazwaPliku.Replace(".cs", "("))
                        && !linia.Contains("class"))
                    {
                        raport.Add($"🔧 Konstruktor: `{linia}`");
                        liczbaMetod++;
                        continue;
                    }

                    // Metoda
                    if (Regex.IsMatch(linia, @"\b(public|private|protected|internal)\s+(static\s+)?([\w\<\>\[\]]+)\s+\w+\s*\(.*\)\s*{?"))
                    {
                        raport.Add($"🔹 Metoda: `{linia}`");
                        liczbaMetod++;
                        continue;
                    }

                    // Właściwość
                    if (Regex.IsMatch(linia, @"\b(public|private|protected|internal)\s+[\w\<\>\[\]]+\s+\w+\s*\{\s*(get|set)"))
                    {
                        raport.Add($"🔸 Właściwość: `{linia}`");
                        liczbaProps++;
                        continue;
                    }
                }

                sumaKlas += liczbaKlas;
                sumaMetod += liczbaMetod;
                sumaWłaściwości += liczbaProps;

                raport.Add($"📊 W pliku: `{liczbaKlas}` klas, `{liczbaMetod}` metod, `{liczbaProps}` właściwości\n");
            }

            raport.Add("---");
            raport.Add($"### 📦 SUMA");
            raport.Add($"- Klas: `{sumaKlas}`");
            raport.Add($"- Metod: `{sumaMetod}`");
            raport.Add($"- Właściwości: `{sumaWłaściwości}`");
            raport.Add($"- Plików `.cs`: `{pliki.Length}`");

            Directory.CreateDirectory(Path.GetDirectoryName(ŚCIEŻKA_WYNIKU));
            File.WriteAllLines(ŚCIEŻKA_WYNIKU, raport);
            AssetDatabase.Refresh();

            Debug.Log($"✅ Eksport funkcji zakończony ({pliki.Length} plików) → {ŚCIEŻKA_WYNIKU}");
        }
    }
}
