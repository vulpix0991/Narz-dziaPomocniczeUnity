// Autor: AI (na żądanie Vulpixa)
// Cel: Generuje dokumentację API klas na podstawie ich komentarzy XML i sygnatur
// Powiązane: dokumentacja projektu, narzędzia AI, EksporterFunkcji

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.AI
{
    public static class APIDokumentacjaGenerator
    {
        private const string outputPath = "Assets/Dokumentacja/api_dokumentacja.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/APIDokumentacjaGenerator")]

    public static void aPIDokumentacjaGenerator()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> dokumentacja = new();

            dokumentacja.Add("# 📘 Dokumentacja API projektu\n");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaKlasy = Path.GetFileNameWithoutExtension(plik);
                string komentarz = "";
                bool znalezionoKomentarz = false;

                dokumentacja.Add($"## {nazwaKlasy}");

                foreach (string linia in linie)
                {
                    if (linia.Trim().StartsWith("///"))
                    {
                        komentarz += linia.Trim().Replace("///", "").Trim() + " ";
                        znalezionoKomentarz = true;
                    }

                    if (Regex.IsMatch(linia, @"\b(public|private|protected)\s+(static\s+)?(void|[\w<>]+)\s+\w+\s*\("))
                    {
                        string metoda = linia.Trim();
                        if (znalezionoKomentarz)
                        {
                            dokumentacja.Add($"- `{metoda}`\n  > {komentarz.Trim()}");
                            komentarz = "";
                            znalezionoKomentarz = false;
                        }
                        else
                        {
                            dokumentacja.Add($"- `{metoda}`");
                        }
                    }
                }

                dokumentacja.Add(""); // odstęp między klasami
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, dokumentacja);

            Debug.Log($"✅ Wygenerowano dokumentację API ({pliki.Length} plików) → {outputPath}");
            AssetDatabase.Refresh();
        }
    }
}
