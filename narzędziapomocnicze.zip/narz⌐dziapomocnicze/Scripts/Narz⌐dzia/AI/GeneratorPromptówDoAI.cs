// Autor: AI (na żądanie Vulpixa)
// Cel: Generuje zestaw promptów dla AI do analizy klas, metod i architektury projektu
// Powiązane: analiza kodu, dokumentacja, refaktoryzacja

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Narzędzia.Heightmap.AI
{
    public static class GeneratorPromptówDoAI
    {
        private static readonly string folderDoc = "Assets/Dokumentacja/";
        private static readonly string outputPath = folderDoc + $"prompty_{DateTime.Now:yyyy-MM-dd}.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Wygeneruj prompt do AI")]

    public static void generatorPromptówDoAI()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories)
                                      .Where(p => !Path.GetFileName(p).StartsWith("Test"))
                                      .OrderBy(p => p)
                                      .ToArray();

            List<string> prompty = new()
            {
                "# 🤖 Prompt Generator – pytania do AI",
                $"📅 Data: {DateTime.Now:yyyy-MM-dd}",
                ""
            };

            foreach (string plik in pliki)
            {
                string nazwaKlasy = Path.GetFileNameWithoutExtension(plik);
                string ścieżka = plik.Replace("Assets/", "");

                prompty.Add($"## 📂 {nazwaKlasy} ({ścieżka})");
                prompty.Add($"- 🤔 Co robi klasa `{nazwaKlasy}`?");
                prompty.Add($"- 🔍 Jakie metody zawiera `{nazwaKlasy}` i jaka jest ich odpowiedzialność?");
                prompty.Add($"- 🧠 Czy `{nazwaKlasy}` łamie zasadę SRP?");
                prompty.Add($"- 🧩 W jakim module projektu działa ta klasa?");
                prompty.Add($"- 📦 Czy `{nazwaKlasy}` powinna być podzielona na mniejsze klasy?");
                prompty.Add($"- ✅ Czy przestrzega ZASADY_AI.md?");
                prompty.Add("");
            }

            Directory.CreateDirectory(folderDoc);
            File.WriteAllLines(outputPath, prompty);

            Debug.Log($"✅ Wygenerowano prompty dla AI → {outputPath}");
            AssetDatabase.Refresh();
        }
    }
}
