// Autor: AI (na żądanie Vulpixa)
// Cel: Zbiera komentarze z kodu źródłowego – Autor, Cel, DEBUG, XML itp.
// Powiązane: dokumentacja AI, analiza techniczna, EksporterFunkcji

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.AI
{
    public static class ListaKomentarzy
    {
        private const string outputPath = "Assets/Dokumentacja/komentarze_projektu.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/ListaKomentarzy")]

    public static void listaKomentarzy()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            List<string> raport = new();

            raport.Add("# 📜 Lista komentarzy z kodu projektu\n");

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwa = Path.GetFileName(plik);
                List<string> komentarze = new();

                foreach (string linia in linie)
                {
                    string trimmed = linia.Trim();
                    if (trimmed.StartsWith("// Autor:") ||
                        trimmed.StartsWith("// Cel:") ||
                        trimmed.StartsWith("// Powiązane") ||
                        trimmed.StartsWith("// DEBUG") ||
                        trimmed.StartsWith("// TODO") ||
                        trimmed.StartsWith("///") ||
                        trimmed.StartsWith("#if UNITY_EDITOR") ||
                        trimmed.StartsWith("#endif"))
                    {
                        komentarze.Add(trimmed);
                    }
                }

                if (komentarze.Count > 0)
                {
                    raport.Add($"## {nazwa}");
                    komentarze.ForEach(k => raport.Add($"- {k}"));
                    raport.Add("");
                }
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);

            Debug.Log($"📄 Zapisano komentarze projektu → {outputPath}");
            AssetDatabase.Refresh();
        }
    }
}
