// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy kopię wybranych folderów projektu do katalogu /Kopie/YYYY-MM-DD/
// Powiązane: backup, rollback, analiza zmian, diff

using UnityEditor;
using UnityEngine;
using System.IO;
using System;

namespace Narzędzia.Heightmap.Backup
{
    public static class NarzędzieKopiaProjektu
    {
        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Backup/NarzędzieKopiaProjektu")]

    public static void narzędzieKopiaProjektu()
        {
            string data = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            string rootBackup = Path.Combine("Kopie", data);

            string[] folderyDoSkopiowania = new[]
            {
                "Assets/Scripts",
                "Assets/Sceny",
                "Assets/JSON",
                "Assets/Prefaby"
            };

            foreach (string folder in folderyDoSkopiowania)
            {
                if (!Directory.Exists(folder))
                {
                    Debug.LogWarning($"⚠️ Nie znaleziono folderu: {folder}");
                    continue;
                }

                string docelowy = Path.Combine(rootBackup, folder.Replace("Assets/", ""));
                Debug.Log($"📦 Kopiuję: {folder} → {docelowy}");
                KopiujFolder(folder, docelowy);
            }

            AssetDatabase.Refresh();
            Debug.Log($"✅ Zakończono kopię projektu do folderu: {rootBackup}");
        }

        private static void KopiujFolder(string źródło, string cel)
        {
            Directory.CreateDirectory(cel);
            foreach (string plik in Directory.GetFiles(źródło))
            {
                string nowaŚcieżka = Path.Combine(cel, Path.GetFileName(plik));
                File.Copy(plik, nowaŚcieżka, true);
            }

            foreach (string podfolder in Directory.GetDirectories(źródło))
            {
                string nowyFolder = Path.Combine(cel, Path.GetFileName(podfolder));
                KopiujFolder(podfolder, nowyFolder);
            }
        }
    }
}
