// Autor: AI (na żądanie Vulpixa)
// Cel: Tworzy statystyki kodu projektu (liczby klas, metod, pól itd.)
// Powiązane: analiza architektury, przegląd systemu, kontrola jakości

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;

namespace Narzędzia.Heightmap.Struktura
{
    public static class StatystykiKodowe
    {
        private const string outputPath = "Assets/Dokumentacja/statystyki_kodu.md";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Statystyki kodu (.md)")]

    public static void statystykiKodowe()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            int liczbaKlas = 0;
            int liczbaMetod = 0;
            int liczbaEventów = 0;
            int sumaLinii = 0;
            int liczbaPublic = 0;
            int liczbaPrivate = 0;
            int liczbaSerialized = 0;

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                sumaLinii += linie.Length;

                foreach (string linia in linie)
                {
                    string trimmed = linia.Trim();

                    if (Regex.IsMatch(trimmed, @"\bclass\b")) liczbaKlas++;
                    if (Regex.IsMatch(trimmed, @"\b(public|private|protected)\s+(static\s+)?(void|\w+)\s+\w+\s*\(")) liczbaMetod++;
                    if (Regex.IsMatch(trimmed, @"\bevent\s+")) liczbaEventów++;
                    if (Regex.IsMatch(trimmed, @"\[SerializeField\]")) liczbaSerialized++;
                    if (Regex.IsMatch(trimmed, @"\bpublic\s+[\w\<\>\[\]]+\s+\w+;")) liczbaPublic++;
                    if (Regex.IsMatch(trimmed, @"\bprivate\s+[\w\<\>\[\]]+\s+\w+;")) liczbaPrivate++;
                }
            }

            float średniaLiniiNaKlasę = liczbaKlas > 0 ? (float)sumaLinii / liczbaKlas : 0;

            string[] raport =
            {
                "# 📊 Statystyki kodu projektu\n",
                $"- Plików `.cs`: **{pliki.Length}**",
                $"- Klas: **{liczbaKlas}**",
                $"- Metod: **{liczbaMetod}**",
                $"- Eventów: **{liczbaEventów}**",
                $"- Suma linii: **{sumaLinii}**",
                $"- Średnia linii na klasę: **{średniaLiniiNaKlasę:F1}**",
                $"- `public` pól: **{liczbaPublic}**",
                $"- `private` pól: **{liczbaPrivate}**",
                $"- `[SerializeField]`: **{liczbaSerialized}**",
            };

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            File.WriteAllLines(outputPath, raport);
            AssetDatabase.Refresh();

            Debug.Log($"📊 Wygenerowano statystyki kodu → {outputPath}");
        }
    }
}
