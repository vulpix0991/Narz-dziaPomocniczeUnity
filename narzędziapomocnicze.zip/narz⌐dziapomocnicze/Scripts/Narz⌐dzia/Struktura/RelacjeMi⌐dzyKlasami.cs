// Autor: AI (na żądanie Vulpixa)
// Cel: Analizuje zależności klas w projekcie i generuje mapę połączeń
// Powiązane: dokumentacja, analiza architektury, refaktoryzacja

using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Narzędzia.Heightmap.Struktura
{
    public static class RelacjeMiędzyKlasami
    {
        private const string outputMd = "Assets/Dokumentacja/relacje_klas.md";
        private const string outputDot = "Assets/Dokumentacja/relacje_klas.dot";

        [MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Mapa zależności klas")]

    public static void relacjeMiędzyKlasami()
        {
            string[] pliki = Directory.GetFiles("Assets/Scripts", "*.cs", SearchOption.AllDirectories);
            Dictionary<string, HashSet<string>> zależności = new();

            foreach (string plik in pliki)
            {
                string[] linie = File.ReadAllLines(plik);
                string nazwaPliku = Path.GetFileNameWithoutExtension(plik);
                zależności[nazwaPliku] = new HashSet<string>();

                foreach (string linia in linie)
                {
                    foreach (var innaKlasa in zależności.Keys)
                    {
                        if (innaKlasa == nazwaPliku) continue;
                        if (linia.Contains(innaKlasa))
                            zależności[nazwaPliku].Add(innaKlasa);
                    }
                }
            }

            // Markdown
            List<string> raport = new();
            raport.Add("# 🔗 Relacje między klasami\n");

            foreach (var para in zależności)
            {
                if (para.Value.Count == 0) continue;
                raport.Add($"## {para.Key}");
                foreach (var z in para.Value)
                    raport.Add($"- używa `{z}`");
                raport.Add("");
            }

            File.WriteAllLines(outputMd, raport);

            // DOT
            List<string> dot = new();
            dot.Add("digraph G {");
            dot.Add("rankdir=LR;");

            foreach (var para in zależności)
            {
                foreach (var z in para.Value)
                    dot.Add($"    \"{para.Key}\" -> \"{z}\";");
            }

            dot.Add("}");
            File.WriteAllLines(outputDot, dot);

            Debug.Log($"🔗 Wygenerowano relacje klas → {outputMd}, {outputDot}");
            AssetDatabase.Refresh();
        }
    }
}
