# 🏷️ Tagi klas i funkcji

| Plik | Klasa | Tagi |
|------|-------|------|
| `APIDokumentacjaGenerator.cs` | `APIDokumentacjaGenerator` | [Debug] |
| `EksporterFunkcji.cs` | `EksporterFunkcji` | [STATUS:KOMPLETNY] [Debug] |
| `GeneratorPlikuZasadyAI.cs` | `GeneratorPlikuZasadyAI` | [Debug] |
| `GeneratorPromptówDoAI.cs` | `GeneratorPromptówDoAI` | [Debug] |
| `ListaKomentarzy.cs` | `ListaKomentarzy` | [Debug] |
| `SpisTypówDanych.cs` | `SpisTypówDanych` | [Data] |
| `TaggerKlasIFunkcji.cs` | `TaggerKlasIFunkcji` | [STATUS:KOMPLETNY] [Debug] |
| `GeneratorPelnychStrukturCS.cs` | `GeneratorPelnychStrukturCS` | [Debug] |
| `DiffPlikówProjektu.cs` | `DiffPlikówProjektu` | [Debug] |
| `NarzędzieKopiaProjektu.cs` | `NarzędzieKopiaProjektu` | [Debug] |
| `VersionTracker.cs` | `VersionTracker` | [Debug] |
| `BrushTransform.cs` | `BrushTransform` | - |
| `AutoKategoryzator.cs` | `AutoKategoryzator` | [Debug] |
| `AutoPoprawiaczNazwFunkcji.cs` | `AutoPoprawiaczNazwFunkcji` | [Debug] |
| `EksporterRelacjiPrefab.cs` | `EksporterRelacjiPrefab` | [Debug] |
| `IndeksPrefabów.cs` | `IndeksPrefabów` | [Debug] |
| `KreatorNowejKlasy.cs` | `KreatorNowejKlasy` | [Debug] |
| `SkanerDialogówISkrótów.cs` | `SkanerDialogówISkrótów` | [Debug] |
| `SkanerDuplikacjiKodu.cs` | `SkanerDuplikacjiKodu` | [Debug] |
| `SpisScenZOpisami.cs` | `SpisScenZOpisami` | [Debug] |
| `ZliczaczNieużywanychPlików.cs` | `ZliczaczNieużywanychPlików` | [Debug] |
| `PorównywarkaStruktur.cs` | `PorównywarkaStruktur` | [Debug] |
| `RelacjeMiędzyKlasami.cs` | `RelacjeMiędzyKlasami` | [Debug] |
| `SnapshotProjektu.cs` | `SnapshotProjektu` | [Debug] |
| `StatystykiKodowe.cs` | `StatystykiKodowe` | [Debug] |
| `StrukturaKatalogówDoTXT.cs` | `StrukturaKatalogówDoTXT` | [Debug] |
| `ChecklistyZgodności.cs` | `ChecklistyZgodności` | [STATUS:KOMPLETNY] [Debug] |
| `LicznikTagówDebug.cs` | `LicznikTagówDebug` | [Debug] |
| `ValidatorPlikówHeightmapy.cs` | `ValidatorPlikówHeightmapy` | [STATUS:KOMPLETNY] [Debug] |
| `AnalizaStatystyk.cs` | `AnalizaStatystyk` | [STATUS:KOMPLETNY] [Debug] |
| `DANE_STATYSTYK.cs` | `DANE_STATYSTYK` | [Data] [STATUS:KOMPLETNY] |
| `ParserHierarchii.cs` | `ParserHierarchii` | [STATUS:DO ROZDZIELENIA] [Debug] |
| `RaportMarkdown.cs` | `RaportMarkdown` | [STATUS:KOMPLETNY] [Debug] |
| `EksportSceny.cs` | `EksportSceny` | [Debug] |
| `FormatterHierarchii.cs` | `FormatterHierarchii` | [Debug] |
| `ZbieraczHierarchii.cs` | `ZbieraczHierarchii` | [Debug] |
| `CzekaczNaPlik.cs` | `CzekaczNaPlik` | [Debug] |
| `DebugerSceny.cs` | `DebugerSceny` | [Debug] |
| `PlikEksportuHelper.cs` | `PlikEksportuHelper` | [Debug] |
