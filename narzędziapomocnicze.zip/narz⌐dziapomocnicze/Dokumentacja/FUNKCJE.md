# 📄 Lista klas, metod, właściwości i statusów w projekcie

## 📄 APIDokumentacjaGenerator.cs
🧩 Klasa: `public static class APIDokumentacjaGenerator`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/APIDokumentacjaGenerator")]`
🔹 Metoda: `public static void aPIDokumentacjaGenerator()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 EksporterFunkcji.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public static class EKSPORTER_FUNKCJI`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Eksporter funkcji i klas")]`
🔹 Metoda: `public static void EKSPORTUJ()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 GeneratorPlikuZasadyAI.cs
🧩 Klasa: `public static class GeneratorPlikuZasadyAI`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Generuj ZASADY_AI.md")]`
🔹 Metoda: `public static void generatorPlikuZasadyAI()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 GeneratorPromptówDoAI.cs
🧩 Klasa: `public static class GeneratorPromptówDoAI`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Wygeneruj prompt do AI")]`
🔹 Metoda: `public static void generatorPromptówDoAI()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 ListaKomentarzy.cs
🧩 Klasa: `public static class ListaKomentarzy`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/ListaKomentarzy")]`
🔹 Metoda: `public static void listaKomentarzy()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 SpisTypówDanych.cs
🧩 Klasa: `public static class SpisTypówDanych`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/SpisTypówDanych")]`
🔹 Metoda: `public static void spisTypówDanych()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 TaggerKlasIFunkcji.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public static class TAGGER_KLAS_I_FUNKCJI`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/AI/Spis klas z tagami")]`
🔹 Metoda: `public static void GENERUJ_TABELĘ_TAGÓW()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 GeneratorPelnychStrukturCS.cs
🧩 Klasa: `public static class GeneratorPelnychStrukturCS`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/📦 Zbierz wszystkie pliki tekstowe do .txt")]`
🔹 Metoda: `public static void ZbierzWszystkieTekstowe()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 DiffPlikówProjektu.cs
🧩 Klasa: `public static class DiffPlikówProjektu`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Backup/DiffPlikówProjektu")]`
🔹 Metoda: `public static void diffPlikówProjektu()`
🔹 Metoda: `private static string ObliczHash(string tekst)`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 NarzędzieKopiaProjektu.cs
🧩 Klasa: `public static class NarzędzieKopiaProjektu`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Backup/NarzędzieKopiaProjektu")]`
🔹 Metoda: `public static void narzędzieKopiaProjektu()`
🔹 Metoda: `private static void KopiujFolder(string źródło, string cel)`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 VersionTracker.cs
🧩 Klasa: `public static class VersionTracker`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Backup/VersionTracker")]`
🔹 Metoda: `public static void versionTracker()`
🔹 Metoda: `private static string ObliczSHA1(string tekst)`
🔖 Atrybut: `[System.Serializable]`
🧩 Klasa: `private class SnapshotContainer`
📊 W pliku: `2` klas, `2` metod, `0` właściwości

## 📄 BrushTransform.cs
🧩 Klasa: `public class BrushTransform : MonoBehaviour`
📊 W pliku: `1` klas, `0` metod, `0` właściwości

## 📄 AutoKategoryzator.cs
🧩 Klasa: `public static class AutoKategoryzator`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/AutoKategoryzator")]`
🔹 Metoda: `public static void autoKategoryzator()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 AutoPoprawiaczNazwFunkcji.cs
🧩 Klasa: `public static class AutoPoprawiaczNazwFunkcji`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Auto-popraw nazwy metod Uruchom()")]`
🔹 Metoda: `public static void AutoPoprawNazwyFunkcji()`
🔹 Metoda: `private static string GenerujNazweMetody(string nazwaKlasy)`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 EksporterRelacjiPrefab.cs
🧩 Klasa: `public static class EksporterRelacjiPrefab`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/EksporterRelacjiPrefab")]`
🔹 Metoda: `public static void eksporterRelacjiPrefab()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 IndeksPrefabów.cs
🧩 Klasa: `public static class IndeksPrefabów`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/IndeksPrefabów")]`
🔹 Metoda: `public static void indeksPrefabów()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 KreatorNowejKlasy.cs
🧩 Klasa: `public class KreatorNowejKlasy : EditorWindow`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/Kreator nowej klasy...")]`
🔹 Metoda: `public static void OtwórzOkno()`
🔹 Metoda: `private void OnGUI()`
🔹 Metoda: `private void GenerujPlik()`
📊 W pliku: `1` klas, `3` metod, `0` właściwości

## 📄 SkanerDialogówISkrótów.cs
🧩 Klasa: `public static class SkanerDialogówISkrótów`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/SkanerDialogówISkrótów")]`
🔹 Metoda: `public static void skanerDialogówISkrótów()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 SkanerDuplikacjiKodu.cs
🧩 Klasa: `public static class SkanerDuplikacjiKodu`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/SkanerDuplikacjiKodu")]`
🔹 Metoda: `public static void skanerDuplikacjiKodu()`
🔹 Metoda: `private static string ObliczHash(string tekst)`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 SpisScenZOpisami.cs
🧩 Klasa: `public static class SpisScenZOpisami`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/SpisScenZOpisami")]`
🔹 Metoda: `public static void spisScenZOpisami()`
🔹 Metoda: `private static string ZnajdzKomentarz(string path)`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 ZliczaczNieużywanychPlików.cs
🧩 Klasa: `public static class ZliczaczNieużywanychPlików`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Edytor/Zliczacz nieużywanych plików")]`
🔹 Metoda: `public static void zliczaczNieużywanychPlików()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 PorównywarkaStruktur.cs
🧩 Klasa: `public static class PorównywarkaStruktur`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/PorównywarkaStruktur")]`
🔹 Metoda: `public static void porównywarkaStruktur()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 RelacjeMiędzyKlasami.cs
🧩 Klasa: `public static class RelacjeMiędzyKlasami`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Mapa zależności klas")]`
🔹 Metoda: `public static void relacjeMiędzyKlasami()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 SnapshotProjektu.cs
🧩 Klasa: `public static class SnapshotProjektu`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Snapshot struktury projektu")]`
🔹 Metoda: `public static void snapshotProjektu()`
🔖 Atrybut: `[System.Serializable]`
🧩 Klasa: `private class Entry`
🔖 Atrybut: `[System.Serializable]`
🧩 Klasa: `private class Container`
📊 W pliku: `3` klas, `1` metod, `0` właściwości

## 📄 StatystykiKodowe.cs
🧩 Klasa: `public static class StatystykiKodowe`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Statystyki kodu (.md)")]`
🔹 Metoda: `public static void statystykiKodowe()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 StrukturaKatalogówDoTXT.cs
🧩 Klasa: `public static class StrukturaKatalogówDoTXT`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Struktura/Utwórz strukturę folderów")]`
🔹 Metoda: `public static void strukturaKatalogówDoTXT()`
🔹 Metoda: `private static void PrzejdźRekursywnie(string katalog, StreamWriter writer, int poziom)`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 ChecklistyZgodności.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public static class CHECKLISTY_ZGODNOŚCI`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/ChecklistyZgodności")]`
🔹 Metoda: `public static void GENERUJ_CHECKLISTĘ()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 LicznikTagówDebug.cs
🧩 Klasa: `public static class LicznikTagówDebug`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Zlicz tagi TODO / DEBUG")]`
🔹 Metoda: `public static void licznikTagówDebug()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 ValidatorPlikówHeightmapy.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public static class VALIDATOR_PLIKÓW_HEIGHTMAPY`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Walidacja/Validator projektu")]`
🔹 Metoda: `public static void WALIDUJ_PROJEKT()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 AnalizaStatystyk.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public static class AnalizaStatystyk`
🔹 Metoda: `public static void Analizuj()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 DANE_STATYSTYK.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public class DaneStatystyk`
📊 W pliku: `1` klas, `0` metod, `0` właściwości

## 📄 ParserHierarchii.cs
🧾 STATUS: `DO ROZDZIELENIA`
🧩 Klasa: `public static class ParserHierarchii`
🔹 Metoda: `public static DaneStatystyk Przetwórz(string[] linie)`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 RaportMarkdown.cs
🧾 STATUS: `KOMPLETNY`
🧩 Klasa: `public static class RaportMarkdown`
🔹 Metoda: `public static void Generuj(DaneStatystyk dane, string scena, string ścieżka = "Assets/DOKUMENTACJA/ANALIZA_HIERARCHII.md")`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 EksportSceny.cs
🧩 Klasa: `public static class EksportSceny`
🔹 Metoda: `public static void EksportujHierarchie()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 FormatterHierarchii.cs
🧩 Klasa: `public static class FormatterHierarchii`
🔹 Metoda: `public static string Formatuj(string nazwaSceny, GameObject[] rootObiekty)`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 ZbieraczHierarchii.cs
🧩 Klasa: `public static class ZbieraczHierarchii`
🔹 Metoda: `public static void Zbierz(GameObject obiekt, int poziom, StringBuilder sb)`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 CzekaczNaPlik.cs
🧩 Klasa: `public static class CzekaczNaPlik`
🔹 Metoda: `public static void Czekaj(string sciezkaPliku)`
🔹 Metoda: `private static void Sprawdz()`
📊 W pliku: `1` klas, `2` metod, `0` właściwości

## 📄 DebugerSceny.cs
🧩 Klasa: `public static class DebugerSceny`
🔖 Atrybut: `[MenuItem("Narzędzia/Narzędzia_pomocnicze/Debug/🧠 Debuguj aktywną scenę (eksport + analiza)")]`
🔹 Metoda: `public static void DebugujScene()`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

## 📄 PlikEksportuHelper.cs
🧩 Klasa: `public static class PlikEksportuHelper`
🔹 Metoda: `public static string PrzygotujPlikEksportu(string nazwaSceny)`
📊 W pliku: `1` klas, `1` metod, `0` właściwości

---
### 📦 SUMA
- Klas: `42`
- Metod: `47`
- Właściwości: `0`
- Plików `.cs`: `39`
