﻿# 🧹 Nieużywane pliki w projekcie

⚠ Znaleziono 3 plików, które nie są referencjami w kodzie:

❌ `Scripts/Narzędzia/AI/TaggerKlasIFunkcji.cs`
❌ `Scripts/Narzędzia/Automatyzacja/Analiza/DANE_STATYSTYK.cs`
❌ `Scripts/Narzędzia/Walidacja/ValidatorPlikówHeightmapy.cs`
