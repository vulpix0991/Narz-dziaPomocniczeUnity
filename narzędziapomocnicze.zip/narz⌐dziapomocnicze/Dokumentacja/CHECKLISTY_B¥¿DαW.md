# ❗ Lista błędów i ostrzeżeń w kodzie

❌ `APIDokumentacjaGenerator.cs` → brak komentarza STATUS
❌ `EksporterFunkcji.cs` → brak nagłówka AI (// Autor:)
🔴 `GeneratorPlikuZasadyAI.cs` → użycie GameObject.Find() w linii 58
🔴 `GeneratorPlikuZasadyAI.cs` → użycie GameObject.Find() w linii 89
❌ `GeneratorPlikuZasadyAI.cs` → brak komentarza STATUS
⚠️ `GeneratorPlikuZasadyAI.cs` → więcej niż jedna klasa w pliku
🔶 `GeneratorPlikuZasadyAI.cs` → logika w Update()
❌ `GeneratorPromptówDoAI.cs` → brak komentarza STATUS
❌ `ListaKomentarzy.cs` → brak komentarza STATUS
❌ `SpisTypówDanych.cs` → brak komentarza STATUS
⚠️ `SpisTypówDanych.cs` → więcej niż jedna klasa w pliku
❌ `TaggerKlasIFunkcji.cs` → brak nagłówka AI (// Autor:)
❌ `GeneratorPelnychStrukturCS.cs` → brak komentarza STATUS
❌ `DiffPlikówProjektu.cs` → brak komentarza STATUS
❌ `NarzędzieKopiaProjektu.cs` → brak komentarza STATUS
❌ `VersionTracker.cs` → brak komentarza STATUS
⚠️ `VersionTracker.cs` → więcej niż jedna klasa w pliku
❌ `BrushTransform.cs` → brak komentarza STATUS
❌ `AutoKategoryzator.cs` → brak komentarza STATUS
❌ `AutoPoprawiaczNazwFunkcji.cs` → brak komentarza STATUS
❌ `EksporterRelacjiPrefab.cs` → brak komentarza STATUS
❌ `IndeksPrefabów.cs` → brak komentarza STATUS
❌ `KreatorNowejKlasy.cs` → brak komentarza STATUS
❌ `SkanerDialogówISkrótów.cs` → brak komentarza STATUS
❌ `SkanerDuplikacjiKodu.cs` → brak komentarza STATUS
❌ `SpisScenZOpisami.cs` → brak komentarza STATUS
❌ `ZliczaczNieużywanychPlików.cs` → brak komentarza STATUS
❌ `PorównywarkaStruktur.cs` → brak komentarza STATUS
❌ `RelacjeMiędzyKlasami.cs` → brak komentarza STATUS
❌ `SnapshotProjektu.cs` → brak komentarza STATUS
⚠️ `SnapshotProjektu.cs` → więcej niż jedna klasa w pliku
❌ `StatystykiKodowe.cs` → brak komentarza STATUS
❌ `StrukturaKatalogówDoTXT.cs` → brak komentarza STATUS
❌ `ChecklistyZgodności.cs` → brak nagłówka AI (// Autor:)
❌ `LicznikTagówDebug.cs` → brak komentarza STATUS
🔴 `ValidatorPlikówHeightmapy.cs` → użycie GameObject.Find() w linii 3
🔴 `ValidatorPlikówHeightmapy.cs` → użycie GameObject.Find() w linii 49
❌ `ValidatorPlikówHeightmapy.cs` → brak nagłówka AI (// Autor:)
⚠️ `ValidatorPlikówHeightmapy.cs` → więcej niż jedna klasa w pliku
🔶 `ValidatorPlikówHeightmapy.cs` → logika w Update()
❌ `AnalizaStatystyk.cs` → brak nagłówka AI (// Autor:)
❌ `DANE_STATYSTYK.cs` → brak nagłówka AI (// Autor:)
❌ `DANE_STATYSTYK.cs` → brak [System.Serializable]
❌ `ParserHierarchii.cs` → brak nagłówka AI (// Autor:)
❌ `RaportMarkdown.cs` → brak nagłówka AI (// Autor:)
❌ `EksportSceny.cs` → brak komentarza STATUS
❌ `FormatterHierarchii.cs` → brak komentarza STATUS
❌ `ZbieraczHierarchii.cs` → brak komentarza STATUS
❌ `CzekaczNaPlik.cs` → brak nagłówka AI (// Autor:)
❌ `CzekaczNaPlik.cs` → brak komentarza STATUS
❌ `DebugerSceny.cs` → brak komentarza STATUS
❌ `PlikEksportuHelper.cs` → brak komentarza STATUS
