# 📘 Dokumentacja API projektu

## APIDokumentacjaGenerator
- `public static void aPIDokumentacjaGenerator()`

## EksporterFunkcji
- `public static void EKSPORTUJ()`

## GeneratorPlikuZasadyAI
- `public static void generatorPlikuZasadyAI()`

## GeneratorPromptówDoAI
- `public static void generatorPromptówDoAI()`

## ListaKomentarzy
- `public static void listaKomentarzy()`

## SpisTypówDanych
- `public static void spisTypówDanych()`

## TaggerKlasIFunkcji
- `public static void GENERUJ_TABELĘ_TAGÓW()`

## GeneratorPelnychStrukturCS
- `public static void ZbierzWszystkieTekstowe()`

## DiffPlikówProjektu
- `public static void diffPlikówProjektu()`
- `private static string ObliczHash(string tekst)`

## NarzędzieKopiaProjektu
- `public static void narzędzieKopiaProjektu()`
- `private static void KopiujFolder(string źródło, string cel)`

## VersionTracker
- `public static void versionTracker()`
- `private static string ObliczSHA1(string tekst)`

## BrushTransform

## AutoKategoryzator
- `public static void autoKategoryzator()`

## AutoPoprawiaczNazwFunkcji
- `public static void AutoPoprawNazwyFunkcji()`
- `private static string GenerujNazweMetody(string nazwaKlasy)`

## EksporterRelacjiPrefab
- `public static void eksporterRelacjiPrefab()`

## IndeksPrefabów
- `public static void indeksPrefabów()`

## KreatorNowejKlasy
- `public static void OtwórzOkno()`
- `private void OnGUI()`
- `private void GenerujPlik()`

## SkanerDialogówISkrótów
- `public static void skanerDialogówISkrótów()`

## SkanerDuplikacjiKodu
- `public static void skanerDuplikacjiKodu()`
- `private static string ObliczHash(string tekst)`

## SpisScenZOpisami
- `public static void spisScenZOpisami()`
- `private static string ZnajdzKomentarz(string path)`

## ZliczaczNieużywanychPlików
- `public static void zliczaczNieużywanychPlików()`

## PorównywarkaStruktur
- `public static void porównywarkaStruktur()`

## RelacjeMiędzyKlasami
- `public static void relacjeMiędzyKlasami()`

## SnapshotProjektu
- `public static void snapshotProjektu()`

## StatystykiKodowe
- `public static void statystykiKodowe()`

## StrukturaKatalogówDoTXT
- `public static void strukturaKatalogówDoTXT()`
- `private static void PrzejdźRekursywnie(string katalog, StreamWriter writer, int poziom)`

## ChecklistyZgodności
- `public static void GENERUJ_CHECKLISTĘ()`

## LicznikTagówDebug
- `public static void licznikTagówDebug()`

## ValidatorPlikówHeightmapy
- `public static void WALIDUJ_PROJEKT()`

## AnalizaStatystyk
- `public static void Analizuj()`

## DANE_STATYSTYK

## ParserHierarchii
- `public static DaneStatystyk Przetwórz(string[] linie)`

## RaportMarkdown
- `public static void Generuj(DaneStatystyk dane, string scena, string ścieżka = "Assets/DOKUMENTACJA/ANALIZA_HIERARCHII.md")`

## EksportSceny
- `public static void EksportujHierarchie()`

## FormatterHierarchii
- `public static string Formatuj(string nazwaSceny, GameObject[] rootObiekty)`

## ZbieraczHierarchii
- `public static void Zbierz(GameObject obiekt, int poziom, StringBuilder sb)`

## CzekaczNaPlik
- `public static void Czekaj(string sciezkaPliku)`
- `private static void Sprawdz()`

## DebugerSceny
- `public static void DebugujScene()`

## PlikEksportuHelper
- `public static string PrzygotujPlikEksportu(string nazwaSceny)`

