# 📜 Lista komentarzy z kodu projektu

## APIDokumentacjaGenerator.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Generuje dokumentację API klas na podstawie ich komentarzy XML i sygnatur
- // Powiązane: dokumentacja projektu, narzędzia AI, EksporterFunkcji

## GeneratorPlikuZasadyAI.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Generuje aktualny plik ZASADY_AI.md na podstawie analizy struktury i kodu projektu
- // Powiązane: dokumentacja, walidacja, refaktoryzacja, automatyczna kontrola jakości

## GeneratorPromptówDoAI.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Generuje zestaw promptów dla AI do analizy klas, metod i architektury projektu
- // Powiązane: analiza kodu, dokumentacja, refaktoryzacja

## ListaKomentarzy.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Zbiera komentarze z kodu źródłowego – Autor, Cel, DEBUG, XML itp.
- // Powiązane: dokumentacja AI, analiza techniczna, EksporterFunkcji

## SpisTypówDanych.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Zbiera wszystkie typy danych oznaczone jako [System.Serializable], ScriptableObject, enum, struct
- // Powiązane: system danych heightmapy, dokumentacja, analiza kodu

## GeneratorPelnychStrukturCS.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Zbiera wszystkie pliki tekstowe (.cs, .shader, .json, .md...) do jednego .txt
- // Powiązane: analiza projektu, backup, snapshot, inspekcja AI

## DiffPlikówProjektu.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Porównuje pliki projektu z kopią zapasową i generuje raport różnic
- // Powiązane: backup, rollback, analiza zmian

## NarzędzieKopiaProjektu.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy kopię wybranych folderów projektu do katalogu /Kopie/YYYY-MM-DD/
- // Powiązane: backup, rollback, analiza zmian, diff

## VersionTracker.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Śledzi zmiany plików .cs na podstawie SHA1 i tworzy snapshot wersji projektu
- // Powiązane: backup, historia zmian, diff

## BrushTransform.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: SZABLON – BrushTransform
- // Powiązane: brak
- // TODO: Implementacja

## AutoKategoryzator.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Wyszukuje pliki niezgodne ze strukturą folderów i proponuje ich relokację
- // Powiązane: struktura projektu, porządek, ZASADY_AI.md

## AutoPoprawiaczNazwFunkcji.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Automatycznie zmienia metody "Uruchom()" na unikalne, zgodne z nazwą klasy
- // Powiązane: SRP, duplikacja metod, MenuItem, refaktoryzacja narzędzi edytora

## EksporterRelacjiPrefab.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Eksportuje relacje prefabów i ich przypiętych komponentów MonoBehaviour
- // Powiązane: dokumentacja, prefab → kod, debug

## IndeksPrefabów.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy pełny indeks prefabów z opisem ich komponentów
- // Powiązane: dokumentacja projektu, debugowanie prefabów, analiza zależności

## KreatorNowejKlasy.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy nowe pliki .cs zgodne z ZASADY_AI.md przez interfejs okienkowy
- // Powiązane: struktura projektu, automatyzacja, porządek
- // Cel: TODO: Opisz cel klasy {nazwaKlasy}
- // Powiązane: TODO: Wymień prefab/scenę/system

## SkanerDialogówISkrótów.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Wyszukuje skróty klawiszowe oraz użycie okien dialogowych i UI edytora
- // Powiązane: debugowanie UI edytora, konflikty skrótów, refaktoryzacja edytora

## SkanerDuplikacjiKodu.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Wyszukuje funkcje o identycznym lub bardzo podobnym ciele w wielu plikach
- // Powiązane: refaktoryzacja, SRP, porządek w systemie heightmap

## SpisScenZOpisami.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy spis wszystkich scen .unity wraz z opisem i klasyfikacją (TEST🗃️ / produkcja)
- // Powiązane: dokumentacja, struktura projektu, kontrola produkcji

## ZliczaczNieużywanychPlików.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Wyszukuje potencjalnie nieużywane pliki: .cs, .prefab, .json, .shader itp.
- // Powiązane: porządki w repozytorium, debug, optymalizacja

## PorównywarkaStruktur.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Porównuje strukturę folderów projektu i tworzy raport różnic
- // Powiązane: snapshoty, kopie zapasowe, analiza zmian

## RelacjeMiędzyKlasami.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Analizuje zależności klas w projekcie i generuje mapę połączeń
- // Powiązane: dokumentacja, analiza architektury, refaktoryzacja

## SnapshotProjektu.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy pełen snapshot struktury projektu w formacie .json i .txt
- // Powiązane: audyt, analiza, porównania, backup, wizualizacja systemu

## StatystykiKodowe.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy statystyki kodu projektu (liczby klas, metod, pól itd.)
- // Powiązane: analiza architektury, przegląd systemu, kontrola jakości

## StrukturaKatalogówDoTXT.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Tworzy spis katalogów i plików z wagą lub liczbą linii kodu
- // Powiązane: analiza struktury, snapshoty, AI, refaktoryzacja

## LicznikTagówDebug.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Zlicza tagi typu DEBUG, TODO, HACK, FIXME w całym kodzie
- // Powiązane: debugowanie, refaktoryzacja, kontrola jakości kodu

## EksportSceny.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Punkt startowy eksportu hierarchii aktywnej sceny
- // Powiązane: ZbieraczHierarchii.cs, FormatterHierarchii.cs

## FormatterHierarchii.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Formatuje dane sceny i obiektów do pliku tekstowego
- // Powiązane: ZbieraczHierarchii.cs

## ZbieraczHierarchii.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Zbiera dane z GameObjectów i ich komponentów w hierarchii
- // Powiązane: FormatterHierarchii.cs

## DebugerSceny.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Uruchamia debug sceny – eksport i odpala czekacza na plik
- // Powiązane: PlikEksportuHelper.cs, CzekaczNaPlik.cs

## PlikEksportuHelper.cs
- // Autor: AI (na żądanie Vulpixa)
- // Cel: Buduje ścieżkę pliku eksportu i usuwa stary
- // Powiązane: DebugerSceny.cs

