# 📊 Statystyki kodu projektu

- Plików `.cs`: **39**
- Klas: **51**
- Metod: **47**
- Eventów: **0**
- Suma linii: **2937**
- Średnia linii na klasę: **57,6**
- `public` pól: **17**
- `private` pól: **0**
- `[SerializeField]`: **3**
