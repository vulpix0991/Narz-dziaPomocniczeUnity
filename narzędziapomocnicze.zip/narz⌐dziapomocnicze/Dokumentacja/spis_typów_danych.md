# 📦 Spis typów danych w projekcie

| Typ | Plik | Pola |
|-----|------|------|
| `GeneratorPlikuZasadyAI` | `GeneratorPlikuZasadyAI.cs` | - |
| `SpisTypówDanych` | `SpisTypówDanych.cs` | - |
| `SnapshotContainer` | `VersionTracker.cs` | - |
| `TypKlasy` | `KreatorNowejKlasy.cs` | - |
| `Container` | `SnapshotProjektu.cs` | public string sciezka<br>public string typ<br>public int bajty<br>public string czas<br>public List<Entry> wpisy |
| `VALIDATOR_PLIKÓW_HEIGHTMAPY` | `ValidatorPlikówHeightmapy.cs` | - |
