# ⌨️ Skróty klawiaturowe i wywołania UI w kodzie

## 📄 Scripts\Narzędzia\Edytor\KreatorNowejKlasy.cs
💬 [40] GUILayout.Button → `if (GUILayout.Button("📦 Utwórz plik"))`

## 📄 Scripts\Narzędzia\Edytor\SkanerDialogówISkrótów.cs
🔑 [18] Input.GetKey → `"Input.GetKey", "Input.GetKeyDown", "KeyCode.",`
🔑 [18] Input.GetKeyDown → `"Input.GetKey", "Input.GetKeyDown", "KeyCode.",`
🔑 [18] KeyCode. → `"Input.GetKey", "Input.GetKeyDown", "KeyCode.",`
🔑 [19] Event.current → `"Event.current", "control", "shift", "alt",`
🔑 [19] control → `"Event.current", "control", "shift", "alt",`
🔑 [19] shift → `"Event.current", "control", "shift", "alt",`
🔑 [19] alt → `"Event.current", "control", "shift", "alt",`
🔑 [20] ShortcutManager.RegisterShortcut → `"ShortcutManager.RegisterShortcut"`
💬 [25] EditorUtility.DisplayDialog → `"EditorUtility.DisplayDialog",`
💬 [26] EditorUtility.OpenFilePanel → `"EditorUtility.OpenFilePanel",`
💬 [27] EditorGUI.Popup → `"EditorGUI.Popup",`
💬 [28] GUILayout.Button → `"GUILayout.Button",`
💬 [29] EditorGUILayout.Toggle → `"EditorGUILayout.Toggle",`
💬 [30] EditorGUILayout.Slider → `"EditorGUILayout.Slider"`

