# 🔗 Relacje między klasami

## ListaKomentarzy
- używa `EksporterFunkcji`

## DANE_STATYSTYK
- używa `AnalizaStatystyk`

## ParserHierarchii
- używa `AnalizaStatystyk`

## RaportMarkdown
- używa `AnalizaStatystyk`
- używa `ParserHierarchii`

## ZbieraczHierarchii
- używa `FormatterHierarchii`

## CzekaczNaPlik
- używa `AnalizaStatystyk`

## DebugerSceny
- używa `CzekaczNaPlik`
- używa `EksportSceny`

## PlikEksportuHelper
- używa `DebugerSceny`

