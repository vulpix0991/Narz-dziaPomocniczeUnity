# 🧮 Liczba tagów TODO / DEBUG / HACK w projekcie

## ListaKomentarzy.cs
- // DEBUG: **1**
- // TODO: **1**
- #if UNITY_EDITOR: **1**

## BrushTransform.cs
- // TODO: **1**

## AutoPoprawiaczNazwFunkcji.cs
- // DEBUG: **4**

## LicznikTagówDebug.cs
- // DEBUG: **1**
- // TODO: **1**
- // HACK: **1**
- // FIXME: **1**
- #if UNITY_EDITOR: **1**
- #region: **1**
- #pragma warning: **1**

## EksportSceny.cs
- // DEBUG: **3**

## FormatterHierarchii.cs
- // DEBUG: **2**

## ZbieraczHierarchii.cs
- // DEBUG: **5**

## DebugerSceny.cs
- // DEBUG: **3**

## PlikEksportuHelper.cs
- // DEBUG: **4**

